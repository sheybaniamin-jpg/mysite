import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  boolean,
  jsonb,
  pgEnum,
} from "drizzle-orm/pg-core";

export const clubStatusEnum = pgEnum("club_status", [
  "PENDING_APPROVAL",
  "APPROVED",
  "REJECTED",
  "SUSPENDED",
]);
export const matchStatusEnum = pgEnum("match_status", [
  "SCHEDULED",
  "LIVE",
  "FINISHED",
  "POSTPONED",
]);
export const leagueEnum = pgEnum("league_key", [
  // فوتبال شهرستان
  "U8_12",
  "U12_15",
  "U15_18",
  "ADULT",
  // فوتسال کشوری
  "FUTSAL1",
  "FUTSAL2",
  // لیگ‌های فوتسال استان
  "F_PROV_JAVANAN",
  "F_PROV_NOJAVANAN",
  "F_PROV_NONAHALAN",
  // لیگ فوتسال شهرستان
  "F_CITY_OMID",
  "F_CITY_NOJAVANAN",
  "F_CITY_NONAHALAN",
  // لیگ‌های آزاد فوتسال
  "F_RAMDAN",
  "F_EDARAT",
]);
export const transferStatusEnum = pgEnum("transfer_status", [
  "PENDING",
  "APPROVED",
  "REJECTED",
]);

// ─── باشگاه‌ها ───────────────────────────────────────────────
export const clubs = pgTable("clubs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  ownerName: text("owner_name").notNull(),
  ownerNationalId: text("owner_national_id").notNull(),
  ownerPhone: text("owner_phone").notNull(),
  activityType: text("activity_type").notNull(),
  licenseNo: text("license_no"),
  address: text("address"),
  description: text("description"),
  status: clubStatusEnum("status").notNull().default("PENDING_APPROVAL"),
  username: text("username"),
  password: text("password"),
  foundedYear: integer("founded_year"),
  /* 📷 مسیر لوگوی باشگاه را می‌توانید اینجا ذخیره کنید (مثلاً images/logos/jazireh.png) */
  logo: text("logo"),
  profile: jsonb("profile").$type<{
    staff?: { name: string; role: string }[];
    trainings?: { day: string; time: string; venue: string }[];
    colors?: string;
    wizardDone?: boolean;
  }>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── بازیکنان ────────────────────────────────────────────────
export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  nationalId: text("national_id"),
  birthYear: integer("birth_year"),
  position: text("position"),
  jersey: integer("jersey"),
  category: text("category").notNull().default("FIRST"), // FIRST | ACADEMY
  insurance: text("insurance").notNull().default("NONE"), // VALID | EXPIRED | NONE
  insuranceExpiry: text("insurance_expiry"),
  /* 📷 عکس بازیکن — از طریق پنل باشگاه آپلود می‌شود */
  photo: text("photo"),
});

// ─── مسابقات ─────────────────────────────────────────────────
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  league: leagueEnum("league").notNull(),
  week: integer("week").notNull().default(1),
  homeName: text("home_name").notNull(),
  awayName: text("away_name").notNull(),
  homeClubId: integer("home_club_id"),
  awayClubId: integer("away_club_id"),
  homeScore: integer("home_score"),
  awayScore: integer("away_score"),
  status: matchStatusEnum("status").notNull().default("SCHEDULED"),
  dateTime: timestamp("date_time").notNull(),
  venue: text("venue"),
  refereeId: integer("referee_id"),
  attendance: integer("attendance"),
});

export const matchEvents = pgTable("match_events", {
  id: serial("id").primaryKey(),
  matchId: integer("match_id")
    .notNull()
    .references(() => matches.id, { onDelete: "cascade" }),
  minute: integer("minute").notNull(),
  type: text("type").notNull(), // goal | owngoal | penalty | yellow | red
  playerName: text("player_name").notNull(),
  side: text("side").notNull(), // HOME | AWAY
  note: text("note"),
});

// ─── داوران ──────────────────────────────────────────────────
export const referees = pgTable("referees", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  grade: text("grade").notNull(),
  kind: text("kind").notNull().default("فوتبال"), // فوتبال | فوتسال
  city: text("city"),
  yearsActive: integer("years_active").default(0),
  matchesCount: integer("matches_count").default(0),
  active: boolean("active").default(true),
});

// ─── اخبار ───────────────────────────────────────────────────
export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  excerpt: text("excerpt"),
  body: text("body"),
  /* 📷 تصویر شاخص خبر — مسیر فایل را در پوشه تصاویر قرار دهید و آدرس را اینجا بگذارید */
  image: text("image"),
  tags: jsonb("tags").$type<string[]>(),
  featured: boolean("featured").default(false),
  views: integer("views").default(0),
  publishedAt: timestamp("published_at").defaultNow().notNull(),
});

// ─── دوره‌های آموزشی ─────────────────────────────────────────
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  kind: text("kind").notNull(), // مربیگری | داوری | عمومی
  instructor: text("instructor"),
  startDate: text("start_date"),
  capacity: integer("capacity").default(30),
  enrolled: integer("enrolled").default(0),
  location: text("location"),
  fee: text("fee"),
  status: text("status").notNull().default("open"), // open | closed | finished
  description: text("description"),
});

export const courseEnrollments = pgTable("course_enrollments", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  nationalId: text("national_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── گالری ───────────────────────────────────────────────────
export const galleryItems = pgTable("gallery_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  kind: text("kind").notNull().default("IMAGE"), // IMAGE | VIDEO
  /* 📷 مسیر فایل تصویر یا ویدئو */
  url: text("url").notNull(),
  category: text("category"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── پیشکسوتان ───────────────────────────────────────────────
export const veterans = pgTable("veterans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  era: text("era"),
  role: text("role"),
  bio: text("bio"),
  achievements: text("achievements"),
  photo: text("photo"),
});

// ─── کمیته انضباطی ───────────────────────────────────────────
export const disciplineCases = pgTable("discipline_cases", {
  id: serial("id").primaryKey(),
  caseNo: text("case_no").notNull(),
  date: text("date").notNull(),
  clubName: text("club_name"),
  playerName: text("player_name"),
  subject: text("subject").notNull(),
  verdict: text("verdict").notNull(),
  kind: text("kind"), // محرومیت | جریمه نقدی | تذکر
});

// ─── نقل و انتقالات ──────────────────────────────────────────
export const transfers = pgTable("transfers", {
  id: serial("id").primaryKey(),
  playerName: text("player_name").notNull(),
  fromClub: text("from_club").notNull(),
  toClub: text("to_club").notNull(),
  kind: text("kind").notNull().default("TRANSFER"), // TRANSFER | RELEASE
  status: transferStatusEnum("status").notNull().default("PENDING"),
  clubId: integer("club_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── استعدادیابی ─────────────────────────────────────────────
export const talentRegs = pgTable("talent_regs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  birthYear: integer("birth_year").notNull(),
  phone: text("phone").notNull(),
  city: text("city"),
  position: text("position"),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── ثبت‌نام لیگ فوتسال (مثل لیگ ادارات) ─────────────────────
export const futsalSignups = pgTable("futsal_signups", {
  id: serial("id").primaryKey(),
  league: text("league").notNull().default("F_EDARAT"),
  teamName: text("team_name").notNull(),
  contactName: text("contact_name"),
  phone: text("phone").notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
