import { db } from "@/db";
import {
  clubs,
  players,
  matches,
  matchEvents,
  referees,
  news,
  courses,
  courseEnrollments,
  galleryItems,
  veterans,
  disciplineCases,
  transfers,
  talentRegs,
  futsalSignups,
} from "@/db/schema";
import { sql } from "drizzle-orm";
import { randomPassword } from "./utils";

/* ═══════════════════════════════════════════════════════════
   هسته‌گذاری اولیه سامانه (نسخه نهایی — بدون داده دمو)
   - ۱۶ باشگاه فوتبال با نام‌های اعلام‌شده
   - ۸ داور فوتسال + ۱۴ داور فوتبال
   - بقیه بخش‌ها (اخبار، مسابقات، گالری و…) خالی است و
     از پنل مدیریت وارد می‌شود.
   ═══════════════════════════════════════════════════════════ */

/* نام باشگاه → فایل لوگو (در پوشه تصاویر) */
const FOOTBALL_CLUBS: [string, string][] = [
  ["زرین", "images/zarin.png"],
  ["جزیره", "images/jazire.jpg"],
  ["نود", "images/navad.jpg"],
  ["ایریا شوکت", "images/ayriashokat.jpg"],
  ["مهرعظام", "images/mehrezam.jpg"],
  ["بهراد", "images/behrad.webp"],
  ["ایران مهر", "images/iranmehr.jpg"],
  ["نوین", "images/novin.jpg"],
  ["جاویدان", "images/javidan.jpg"],
  ["ملک", "images/malek.jpg"],
  ["سرخ پوشان", "images/sorkposhan.jpg"],
  ["ستارگان ایران", "images/iranstar.png"],
  ["ستارگان کویر", "images/setaregankavir.jpg"],
  ["جوان پارس", "images/javanpars.jpg"],
  ["ایران جوان", "images/iranjavan.jpg"],
  ["پیشگامان", "images/pishgaman.jpg"],
  ["پدیده", "images/bahman.jpg"],
];

const FUTSAL_REFEREES = [
  "محمود طحان",
  "مهدی ابراهیمی",
  "سید ابوالفضل موسوی",
  "حمیدرضا حاجی پور",
  "ابوالفضل جمالی",
  "سید ساجد پور سجادی",
  "بهمن محمدی",
  "ابوالفضل رضایی",
];

const FOOTBALL_REFEREES = [
  "فرهاد حسن پور",
  "مهزیار محمدی پور",
  "حسین آسوده",
  "علی اصغر عدالتی صدر",
  "سید مجتبی باقری",
  "سجاد سمایی",
  "علی نی خنجی",
  "خلیل خسروی",
  "علی سنجری",
  "عرفان عربی",
  "محمدرضا حمزه ای",
  "مهران خسروی",
  "میلاد کدخدا",
  "محمد بهدانی",
];

export async function clearAllData() {
  await db.delete(matchEvents);
  await db.delete(matches);
  await db.delete(courseEnrollments);
  await db.delete(clubs);
  await db.delete(players);
  await db.delete(referees);
  await db.delete(news);
  await db.delete(courses);
  await db.delete(galleryItems);
  await db.delete(veterans);
  await db.delete(disciplineCases);
  await db.delete(transfers);
  await db.delete(talentRegs);
  await db.delete(futsalSignups);
}

export async function seedDemoData() {
  /* باشگاه‌ها — تأییدشده با حساب کاربری (رمز‌ها فقط در پنل مدیریت دیده می‌شوند) */
  await db.insert(clubs).values(
    FOOTBALL_CLUBS.map(([name, logo], i) => ({
      name,
      ownerName: "—",
      ownerNationalId: "—",
      ownerPhone: "—",
      activityType: "فوتبال",
      address: "بیرجند",
      description: "",
      status: "APPROVED" as const,
      username: `club-${String(i + 1).padStart(2, "0")}`,
      password: randomPassword(8),
      logo,
    }))
  );

  /* داوران فوتسال و فوتبال */
  await db.insert(referees).values([
    ...FUTSAL_REFEREES.map((name, i) => ({
      name,
      grade: i < 2 ? "استانی" : "درجه یک",
      kind: "فوتسال",
      city: "بیرجند",
      yearsActive: 0,
      matchesCount: 0,
      active: true,
    })),
    ...FOOTBALL_REFEREES.map((name, i) => ({
      name,
      grade: i < 3 ? "استانی" : "درجه یک",
      kind: "فوتبال",
      city: "بیرجند",
      yearsActive: 0,
      matchesCount: 0,
      active: true,
    })),
  ]);

  /* سایر بخش‌ها عمداً خالی است و از پنل مدیریت ثبت می‌شود:
     اخبار، مسابقات، دوره‌ها، گالری، پیشکسوتان، انضباطی، نقل‌وانتقالات */
}

let seedChecked = false;
export async function ensureSeeded() {
  if (seedChecked) return;
  seedChecked = true;
  try {
    const res = await db.execute(sql`select count(*)::int as c from clubs`);
    const count = Number((res.rows[0] as { c: number })?.c ?? 0);
    if (count === 0) await seedDemoData();
  } catch {
    /* جدول‌ها هنوز ساخته نشده‌اند */
  }
}
