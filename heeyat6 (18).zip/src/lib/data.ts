import { db } from "@/db";
import {
  clubs,
  players,
  matches,
  matchEvents,
  referees,
  news,
  courses,
  courseEnrollments,
  galleryItems,
  veterans,
  disciplineCases,
  transfers,
  talentRegs,
  futsalSignups,
} from "@/db/schema";
import { desc, eq, inArray } from "drizzle-orm";
import { ensureSeeded } from "./seed";

export async function ready() {
  await ensureSeeded();
}

export async function getNews(opts?: { limit?: number; featured?: boolean }) {
  await ready();
  let q = db.select().from(news).orderBy(desc(news.publishedAt));
  if (opts?.featured) q = q.where(eq(news.featured, true)) as typeof q;
  if (opts?.limit) q = q.limit(opts.limit) as typeof q;
  return q;
}

export async function getNewsBySlug(slug: string) {
  await ready();
  const [row] = await db.select().from(news).where(eq(news.slug, slug)).limit(1);
  return row ?? null;
}

export type FullMatch = {
  id: number;
  league: string;
  week: number | null;
  homeName: string;
  awayName: string;
  homeClubId: number | null;
  awayClubId: number | null;
  homeScore: number | null;
  awayScore: number | null;
  status: string;
  dateTime: Date;
  venue: string | null;
  refereeId: number | null;
  attendance: number | null;
  refereeName?: string | null;
};

export async function getMatches(league?: string): Promise<FullMatch[]> {
  await ready();
  let q = db.select().from(matches);
  if (league) q = q.where(eq(matches.league, league as never)) as typeof q;
  const rows = await q.orderBy(desc(matches.dateTime));
  const refIds = [...new Set(rows.map((m) => m.refereeId).filter(Boolean))] as number[];
  const refs = refIds.length ? await db.select().from(referees).where(inArray(referees.id, refIds)) : [];
  const refMap = new Map(refs.map((r) => [r.id, r.name]));
  return rows.map((m) => ({ ...m, refereeName: m.refereeId ? refMap.get(m.refereeId) ?? null : null }));
}

export async function getMatchById(id: number) {
  await ready();
  const [m] = await db.select().from(matches).where(eq(matches.id, id)).limit(1);
  if (!m) return null;
  const evs = await db.select().from(matchEvents).where(eq(matchEvents.matchId, id)).orderBy(matchEvents.minute);
  let refName: string | null = null;
  if (m.refereeId) {
    const [r] = await db.select().from(referees).where(eq(referees.id, m.refereeId)).limit(1);
    refName = r?.name ?? null;
  }
  return { match: m, events: evs, refereeName: refName };
}

export async function getEventsForMatches(ids: number[]) {
  if (!ids.length) return [];
  await ready();
  return db.select().from(matchEvents).where(inArray(matchEvents.matchId, ids));
}

export async function getReferees() {
  await ready();
  return db.select().from(referees).orderBy(desc(referees.matchesCount));
}

export async function getCourses() {
  await ready();
  return db.select().from(courses).orderBy(courses.startDate);
}

export async function getGallery() {
  await ready();
  return db.select().from(galleryItems).orderBy(desc(galleryItems.createdAt));
}

export async function getVeterans() {
  await ready();
  return db.select().from(veterans);
}

export async function getDiscipline() {
  await ready();
  return db.select().from(disciplineCases).orderBy(desc(disciplineCases.id));
}

export async function getTransfers() {
  await ready();
  return db.select().from(transfers).orderBy(desc(transfers.createdAt));
}

export async function getClubs() {
  await ready();
  return db.select().from(clubs).orderBy(clubs.name);
}

export async function getPlayers(clubId?: number) {
  await ready();
  if (clubId) return db.select().from(players).where(eq(players.clubId, clubId));
  return db.select().from(players);
}

export async function getHomeData() {
  await ready();
  const [featuredNews, latestNews, allMatches, refs, allCourses, gallery, vets, discipline, allClubs, allPlayers] =
    await Promise.all([
      getNews({ featured: true, limit: 4 }),
      getNews({ limit: 6 }),
      getMatches(),
      getReferees(),
      getCourses(),
      getGallery(),
      getVeterans(),
      getDiscipline(),
      getClubs(),
      getPlayers(),
    ]);
  return {
    featuredNews,
    latestNews,
    matches: allMatches,
    referees: refs.slice(0, 4),
    courses: allCourses.filter((c) => c.status === "open"),
    gallery: gallery.slice(0, 6),
    veterans: vets,
    discipline: discipline.slice(0, 3),
    clubs: allClubs,
    playersCount: allPlayers.length,
  };
}

export async function getAdminBundle() {
  await ready();
  const [allClubs, allPlayers, allMatches, evs, refs, allNews, allCourses, enrollments, gallery, vets, disc, trs, talents, fSignups] =
    await Promise.all([
      db.select().from(clubs).orderBy(clubs.name),
      db.select().from(players),
      db.select().from(matches).orderBy(matches.dateTime),
      db.select().from(matchEvents),
      db.select().from(referees).orderBy(referees.name),
      db.select().from(news).orderBy(desc(news.publishedAt)),
      db.select().from(courses),
      db.select().from(courseEnrollments),
      db.select().from(galleryItems).orderBy(desc(galleryItems.createdAt)),
      db.select().from(veterans),
      db.select().from(disciplineCases).orderBy(desc(disciplineCases.id)),
      db.select().from(transfers).orderBy(desc(transfers.createdAt)),
      db.select().from(talentRegs).orderBy(desc(talentRegs.createdAt)),
      db.select().from(futsalSignups).orderBy(desc(futsalSignups.createdAt)),
    ]);
  return {
    clubs: allClubs,
    players: allPlayers,
    matches: allMatches,
    events: evs,
    referees: refs,
    news: allNews,
    courses: allCourses,
    enrollments,
    gallery,
    veterans: vets,
    discipline: disc,
    transfers: trs,
    talents,
    futsalSignups: fSignups,
  };
}

export type AdminBundle = Awaited<ReturnType<typeof getAdminBundle>>;
