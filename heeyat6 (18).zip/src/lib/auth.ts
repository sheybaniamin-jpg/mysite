import { createHmac, timingSafeEqual } from "crypto";
import { cookies, headers } from "next/headers";

const COOKIE_NAME = "bfa_auth";

export type Session =
  | { role: "admin" }
  | { role: "club"; clubId: number; name: string };

/** کلید پیش‌فرض سمت سرور؛ اگر متغیر محیطی ADMIN_SECRET_KEY تنظیم شود اولویت با آن است. */
const SERVER_DEFAULT_KEY = "BirjandFA-1404-SecretKey";

function secret(): string {
  return process.env.ADMIN_SECRET_KEY || SERVER_DEFAULT_KEY;
}

export function demoAdminKey(): string {
  return process.env.ADMIN_SECRET_KEY || SERVER_DEFAULT_KEY;
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function encodeSession(s: Session): string {
  const payload = Buffer.from(JSON.stringify(s)).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

export function decodeSession(token: string | undefined): Session | null {
  if (!token) return null;
  const idx = token.lastIndexOf(".");
  if (idx < 0) return null;
  const payload = token.slice(0, idx);
  const sig = token.slice(idx + 1);
  const expected = sign(payload);
  try {
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (data?.role === "admin") return { role: "admin" };
    if (data?.role === "club" && typeof data.clubId === "number")
      return { role: "club", clubId: data.clubId, name: data.name };
    return null;
  } catch {
    return null;
  }
}

export async function setSessionCookie(token: string) {
  const c = await cookies();
  c.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function clearSessionCookie() {
  const c = await cookies();
  c.delete(COOKIE_NAME);
}

export async function getSession(): Promise<Session | null> {
  try {
    // ۱) کوکی (دسترسی مستقیم به سایت)
    const c = await cookies();
    const fromCookie = decodeSession(c.get(COOKIE_NAME)?.value);
    if (fromCookie) return fromCookie;
    // ۲) هدر Authorization (پیش‌نمایش داخل قاب / مرورگرهایی که کوکی ثالث را مسدود می‌کنند)
    const h = await headers();
    const auth = h.get("authorization") ?? "";
    if (auth.startsWith("Bearer ")) return decodeSession(auth.slice(7));
  } catch {
    /* noop */
  }
  return null;
}

export async function requireAdmin(): Promise<boolean> {
  const s = await getSession();
  return s?.role === "admin";
}

export async function requireClub(): Promise<{ clubId: number; name: string } | null> {
  const s = await getSession();
  if (s?.role === "club") return { clubId: s.clubId, name: s.name };
  return null;
}

export function verifyAdminKey(key: string): boolean {
  const expected = secret(); // متغیر محیطی یا کلید پیش‌فرض سرور
  try {
    const a = Buffer.from(key);
    const b = Buffer.from(expected);
    return a.length === b.length && timingSafeEqual(a, b);
  } catch {
    return false;
  }
}
