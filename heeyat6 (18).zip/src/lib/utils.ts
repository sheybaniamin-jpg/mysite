export const LEAGUES: Record<
  string,
  { label: string; short: string; desc: string }
> = {
  // فوتبال شهرستان
  U8_12: { label: "رده سنی ۸ تا ۱۲ سال", short: "۸ تا ۱۲ سال", desc: "لیگ پایه نونهالان شهرستان بیرجند" },
  U12_15: { label: "رده سنی ۱۲ تا ۱۵ سال", short: "۱۲ تا ۱۵ سال", desc: "لیگ پایه نوجوانان شهرستان بیرجند" },
  U15_18: { label: "رده سنی ۱۵ تا ۱۸ سال", short: "۱۵ تا ۱۸ سال", desc: "لیگ پایه جوانان شهرستان بیرجند" },
  ADULT: { label: "رده بزرگسالان", short: "بزرگسالان", desc: "لیگ فوتبال شهرستان بیرجند" },
  // فوتسال کشوری
  FUTSAL1: { label: "لیگ دسته یک فوتسال کشور", short: "لیگ یک کشور", desc: "جدول رسمی لیگ دسته یک فوتسال کشور" },
  FUTSAL2: { label: "لیگ دسته دو فوتسال کشور", short: "لیگ دو کشور", desc: "جدول رسمی لیگ دسته دو فوتسال کشور" },
  // لیگ‌های فوتسال استان
  F_PROV_JAVANAN: { label: "لیگ فوتسال استان — جوانان", short: "استان·جوانان", desc: "لیگ فوتسال جوانان استان" },
  F_PROV_NOJAVANAN: { label: "لیگ فوتسال استان — نوجوانان", short: "استان·نوجوانان", desc: "لیگ فوتسال نوجوانان استان" },
  F_PROV_NONAHALAN: { label: "لیگ فوتسال استان — نونهالان", short: "استان·نونهالان", desc: "لیگ فوتسال نونهالان استان" },
  // لیگ فوتسال شهرستان
  F_CITY_OMID: { label: "لیگ فوتسال شهرستان — امید", short: "شهرستان·امید", desc: "لیگ فوتسال امید شهرستان بیرجند" },
  F_CITY_NOJAVANAN: { label: "لیگ فوتسال شهرستان — نوجوانان", short: "شهرستان·نوجوانان", desc: "لیگ فوتسال نوجوانان شهرستان بیرجند" },
  F_CITY_NONAHALAN: { label: "لیگ فوتسال شهرستان — نونهالان", short: "شهرستان·نونهالان", desc: "لیگ فوتسال نونهالان شهرستان بیرجند" },
  // لیگ‌های آزاد فوتسال
  F_RAMDAN: { label: "جام رمضان فوتسال", short: "جام رمضان", desc: "مسابقات جام رمضان فوتسال بیرجند" },
  F_EDARAT: { label: "لیگ فوتسال ادارات", short: "لیگ ادارات", desc: "لیگ فوتسال ادارات — یادواره مرحوم محمد ابراهیم آرگینی و محمد عرضی" },
};

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function faNum(v: number | string | null | undefined): string {
  if (v === null || v === undefined) return "—";
  return String(v).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

export function faDate(d: string | Date | null | undefined, opts?: Intl.DateTimeFormatOptions): string {
  if (!d) return "—";
  try {
    return new Intl.DateTimeFormat(
      "fa-IR",
      opts ?? { year: "numeric", month: "long", day: "numeric" }
    ).format(new Date(d));
  } catch {
    return "—";
  }
}

export function faDateShort(d: string | Date | null | undefined): string {
  return faDate(d, { month: "2-digit", day: "2-digit" });
}

export function faTime(d: string | Date | null | undefined): string {
  if (!d) return "—";
  try {
    return new Intl.DateTimeFormat("fa-IR", { hour: "2-digit", minute: "2-digit" }).format(new Date(d));
  } catch {
    return "—";
  }
}

export function faWeekday(d: string | Date | null | undefined): string {
  if (!d) return "";
  try {
    return new Intl.DateTimeFormat("fa-IR", { weekday: "long" }).format(new Date(d));
  } catch {
    return "";
  }
}

export function timeAgo(d: Date | string): string {
  const diff = Date.now() - new Date(d).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "لحظاتی پیش";
  if (mins < 60) return `${faNum(mins)} دقیقه پیش`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${faNum(hrs)} ساعت پیش`;
  const days = Math.floor(hrs / 24);
  return `${faNum(days)} روز پیش`;
}

// ─── رنگ و لوگوی تیم‌ها ──────────────────────────────────────
const CREST_PALETTES = [
  ["#c8102e", "#8a0b20"],
  ["#0d47a1", "#082c66"],
  ["#0f9d58", "#0a6b3c"],
  ["#e0a800", "#9c7500"],
  ["#5e35b1", "#3b1f75"],
  ["#00838f", "#00525a"],
  ["#d84315", "#972c0c"],
  ["#37474f", "#1b262b"],
  ["#ad1457", "#6d0b36"],
  ["#2e7d32", "#164a1c"],
];

export function teamColors(name: string): [string, string] {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return CREST_PALETTES[h % CREST_PALETTES.length] as [string, string];
}

export function teamShort(name: string): string {
  const words = name.split(/\s+/).filter(Boolean);
  if (words.length === 1) return words[0].slice(0, 2);
  return words
    .slice(0, 2)
    .map((w) => w[0])
    .join("‌");
}

// ─── جدول رده‌بندی ───────────────────────────────────────────
export type MatchRow = {
  id: number;
  league: string;
  week: number | null;
  homeName: string;
  awayName: string;
  homeScore: number | null;
  awayScore: number | null;
  status: string;
  dateTime: Date | string;
  venue: string | null;
  refereeId: number | null;
};

export type StandingRow = {
  team: string;
  played: number;
  wins: number;
  draws: number;
  losses: number;
  gf: number;
  ga: number;
  gd: number;
  points: number;
  form: ("W" | "D" | "L")[];
};

export function computeStandings(matches: MatchRow[]): StandingRow[] {
  const table: Record<string, StandingRow> = {};
  const get = (team: string) =>
    (table[team] ??= { team, played: 0, wins: 0, draws: 0, losses: 0, gf: 0, ga: 0, gd: 0, points: 0, form: [] });

  const finished = matches
    .filter((m) => m.status === "FINISHED" && m.homeScore !== null && m.awayScore !== null)
    .sort((a, b) => new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime());

  for (const m of finished) {
    const hs = m.homeScore as number;
    const as = m.awayScore as number;
    const home = get(m.homeName);
    const away = get(m.awayName);
    home.played++;
    away.played++;
    home.gf += hs;
    home.ga += as;
    away.gf += as;
    away.ga += hs;
    if (hs > as) {
      home.wins++;
      home.points += 3;
      away.losses++;
      home.form.push("W");
      away.form.push("L");
    } else if (hs < as) {
      away.wins++;
      away.points += 3;
      home.losses++;
      away.form.push("W");
      home.form.push("L");
    } else {
      home.draws++;
      away.draws++;
      home.points++;
      away.points++;
      home.form.push("D");
      away.form.push("D");
    }
  }
  const rows = Object.values(table);
  for (const r of rows) {
    r.gd = r.gf - r.ga;
    r.form = r.form.slice(-5);
  }
  rows.sort((a, b) => b.points - a.points || b.gd - a.gd || b.gf - a.gf || a.team.localeCompare(b.team, "fa"));
  return rows;
}

export function slugify(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9\u0600-\u06FF]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80) || `item-${Date.now()}`;
}

export function randomPassword(len = 8): string {
  const chars = "abcdefghjkmnpqrstuvwxyz23456789";
  let out = "";
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

export function cn(...cls: (string | false | null | undefined)[]): string {
  return cls.filter(Boolean).join(" ");
}

export const NEWS_CATEGORIES = [
  "اخبار هیئت",
  "اخبار مسابقات",
  "اطلاعیه رسمی",
  "آموزش",
  "داوران",
  "مدارس فوتبال",
  "فوتسال",
  "بانوان",
];

export const ACTIVITY_TYPES = [
  "فوتبال بزرگسالان",
  "فوتبال پایه",
  "مدرسه فوتبال",
  "فوتسال",
  "بانوان",
];
