import { db } from "@/db";
import { clubs, courseEnrollments, courses, futsalSignups, news, talentRegs } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { LEAGUES } from "@/lib/utils";
import {
  getDiscipline,
  getGallery,
  getHomeData,
  getMatchById,
  getMatches,
  getNews,
  getNewsBySlug,
  getReferees,
  getVeterans,
  getCourses,
  ready,
} from "@/lib/data";
import { computeStandings } from "@/lib/utils";

export const dynamic = "force-dynamic";

/** سرویس‌های خواندنی عمومی برای صفحات HTML */
export async function GET(req: Request) {
  try {
    await ready();
    const url = new URL(req.url);
    const section = url.searchParams.get("section") ?? "home";

    switch (section) {
      case "home": {
        const d = await getHomeData();
        const standings = computeStandings(d.matches.filter((m) => m.league === "ADULT"));
        return Response.json({ ...d, adultStandings: standings });
      }
      case "news":
        return Response.json({ news: await getNews() });
      case "news-item": {
        const slug = url.searchParams.get("slug") ?? "";
        const article = await getNewsBySlug(slug);
        if (!article) return Response.json({ error: "خبر یافت نشد." }, { status: 404 });
        try {
          await db.update(news).set({ views: (article.views ?? 0) + 1 }).where(eq(news.id, article.id));
        } catch { /* noop */ }
        const related = (await getNews({ limit: 6 })).filter((n) => n.id !== article.id).slice(0, 3);
        return Response.json({ article, related });
      }
      case "matches":
        return Response.json({ matches: await getMatches() });
      case "match": {
        const id = Number(url.searchParams.get("id"));
        const data = await getMatchById(id);
        if (!data) return Response.json({ error: "مسابقه یافت نشد." }, { status: 404 });
        return Response.json(data);
      }
      case "standings": {
        const all = await getMatches();
        const tables: Record<string, unknown> = {};
        for (const key of Object.keys(LEAGUES)) {
          tables[key] = computeStandings(all.filter((m) => m.league === key));
        }
        return Response.json({ tables });
      }
      case "futsal": {
        const all = await getMatches();
        const fut = (league: string) => all.filter((m) => m.league === league);
        const block = (league: string) => {
          const list = fut(league);
          return {
            standings: computeStandings(list),
            finished: list.filter((m) => m.status !== "SCHEDULED").slice(0, 6),
            upcoming: list
              .filter((m) => m.status === "SCHEDULED")
              .sort((a, b) => new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime())
              .slice(0, 6),
          };
        };
        return Response.json({
          leagues: {
            FUTSAL1: block("FUTSAL1"),
            FUTSAL2: block("FUTSAL2"),
            F_PROV_JAVANAN: block("F_PROV_JAVANAN"),
            F_PROV_NOJAVANAN: block("F_PROV_NOJAVANAN"),
            F_PROV_NONAHALAN: block("F_PROV_NONAHALAN"),
            F_CITY_OMID: block("F_CITY_OMID"),
            F_CITY_NOJAVANAN: block("F_CITY_NOJAVANAN"),
            F_CITY_NONAHALAN: block("F_CITY_NONAHALAN"),
            F_RAMDAN: block("F_RAMDAN"),
            F_EDARAT: block("F_EDARAT"),
          },
        });
      }
      case "referees":
        return Response.json({ referees: await getReferees() });
      case "courses":
        return Response.json({ courses: await getCourses() });
      case "gallery":
        return Response.json({ gallery: await getGallery() });
      case "veterans":
        return Response.json({ veterans: await getVeterans() });
      case "discipline":
        return Response.json({ discipline: await getDiscipline() });
      default:
        return Response.json({ error: "بخش نامعتبر" }, { status: 400 });
    }
  } catch (e) {
    console.error("public GET error", e);
    return Response.json({ error: "خطای سرور" }, { status: 500 });
  }
}

/** سرویس‌های ثبت‌نام عمومی (باشگاه، استعدادیابی، دوره‌ها) */
export async function POST(req: Request) {
  try {
    const b = await req.json();
    const action = b?.action as string;

    if (action === "club-application") {
      const required = ["name", "ownerName", "ownerNationalId", "ownerPhone", "activityType", "address"];
      for (const f of required) {
        if (!String(b[f] ?? "").trim()) {
          return Response.json({ error: "لطفاً کلیه فیلدهای الزامی را تکمیل کنید." }, { status: 400 });
        }
      }
      const name = String(b.name).trim();
      const [existing] = await db.select({ id: clubs.id }).from(clubs).where(eq(clubs.name, name)).limit(1);
      if (existing) {
        return Response.json({ error: "باشگاهی با این نام قبلاً ثبت شده است." }, { status: 409 });
      }
      await db.insert(clubs).values({
        name,
        ownerName: String(b.ownerName).trim(),
        ownerNationalId: String(b.ownerNationalId).trim(),
        ownerPhone: String(b.ownerPhone).trim(),
        activityType: String(b.activityType),
        licenseNo: String(b.licenseNo ?? "").trim() || null,
        address: String(b.address).trim(),
        description: [String(b.description ?? "").trim(), b.fileName ? `مدرک پیوست: ${b.fileName}` : ""].filter(Boolean).join(" | ") || null,
        status: "PENDING_APPROVAL",
      });
      return Response.json({ ok: true, status: "PENDING_APPROVAL" });
    }

    if (action === "talent") {
      if (!b.name || !b.phone || !b.birthYear) {
        return Response.json({ error: "نام، سال تولد و شماره تماس الزامی است." }, { status: 400 });
      }
      await db.insert(talentRegs).values({
        name: String(b.name).trim(),
        birthYear: Number(b.birthYear),
        phone: String(b.phone).trim(),
        city: String(b.city ?? "") || null,
        position: String(b.position ?? "") || null,
        note: String(b.note ?? "") || null,
      });
      return Response.json({ ok: true });
    }

    if (action === "futsal-signup") {
      if (!b.teamName || !b.phone) {
        return Response.json({ error: "نام تیم و شماره تماس الزامی است." }, { status: 400 });
      }
      await db.insert(futsalSignups).values({
        league: String(b.league ?? "F_EDARAT"),
        teamName: String(b.teamName).trim(),
        contactName: String(b.contactName ?? "") || null,
        phone: String(b.phone).trim(),
        note: String(b.note ?? "") || null,
      });
      return Response.json({ ok: true });
    }

    if (action === "enroll") {
      if (!b.name || !b.phone || !b.courseId) {
        return Response.json({ error: "نام و شماره تماس الزامی است." }, { status: 400 });
      }
      const [c] = await db.select().from(courses).where(eq(courses.id, Number(b.courseId))).limit(1);
      if (!c || c.status !== "open") return Response.json({ error: "ثبت‌نام این دوره فعال نیست." }, { status: 400 });
      if ((c.enrolled ?? 0) >= (c.capacity ?? 0)) return Response.json({ error: "ظرفیت دوره تکمیل شده است." }, { status: 400 });
      await db.insert(courseEnrollments).values({
        courseId: c.id,
        name: String(b.name).trim(),
        phone: String(b.phone).trim(),
        nationalId: String(b.nationalId ?? "") || null,
      });
      await db.update(courses).set({ enrolled: sql`${courses.enrolled} + 1` }).where(eq(courses.id, c.id));
      return Response.json({ ok: true });
    }

    return Response.json({ error: "عملیات نامعتبر" }, { status: 400 });
  } catch {
    return Response.json({ error: "خطای سرور" }, { status: 500 });
  }
}
