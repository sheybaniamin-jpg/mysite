import { db } from "@/db";
import { clubs, disciplineCases, matches, players, transfers } from "@/db/schema";
import { eq, or, sql } from "drizzle-orm";
import { requireClub } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireClub();
  if (!auth) return Response.json({ error: "دسترسی غیرمجاز" }, { status: 401 });
  const [club] = await db.select().from(clubs).where(eq(clubs.id, auth.clubId)).limit(1);
  if (!club) return Response.json({ error: "باشگاه یافت نشد." }, { status: 404 });
  const [myPlayers, myMatches, myTransfers, discipline, clubNames] = await Promise.all([
    db.select().from(players).where(eq(players.clubId, club.id)),
    db.select().from(matches).where(or(eq(matches.homeClubId, club.id), eq(matches.awayClubId, club.id))).orderBy(matches.dateTime),
    db.select().from(transfers).where(eq(transfers.clubId, club.id)),
    db.select().from(disciplineCases).where(eq(disciplineCases.clubName, club.name)),
    db.select({ name: clubs.name }).from(clubs).where(eq(clubs.status, "APPROVED")),
  ]);
  return Response.json({ club, players: myPlayers, matches: myMatches, transfers: myTransfers, discipline, clubNames: clubNames.map((c) => c.name) });
}

export async function POST(req: Request) {
  const auth = await requireClub();
  if (!auth) return Response.json({ error: "دسترسی غیرمجاز" }, { status: 401 });
  const b = await req.json();
  const action: string = b?.action ?? "";

  try {
    switch (action) {
      case "profile": {
        const [club] = await db.select().from(clubs).where(eq(clubs.id, auth.clubId)).limit(1);
        if (!club) return Response.json({ error: "باشگاه یافت نشد." }, { status: 404 });
        await db
          .update(clubs)
          .set({
            address: String(b.address ?? club.address ?? ""),
            licenseNo: String(b.licenseNo ?? club.licenseNo ?? "") || null,
            description: String(b.description ?? club.description ?? "") || null,
            foundedYear: b.foundedYear ? Number(b.foundedYear) : club.foundedYear,
            profile: {
              staff: Array.isArray(b.staff) ? b.staff : [],
              trainings: Array.isArray(b.trainings) ? b.trainings : [],
              wizardDone: true,
            },
          })
          .where(eq(clubs.id, auth.clubId));
        return Response.json({ ok: true });
      }

      case "player:add": {
        const name = String(b.name ?? "").trim();
        if (!name) return Response.json({ error: "نام بازیکن الزامی است." }, { status: 400 });
        await db.insert(players).values({
          clubId: auth.clubId,
          name,
          nationalId: String(b.nationalId ?? "") || null,
          birthYear: b.birthYear ? Number(b.birthYear) : null,
          position: String(b.position ?? "") || null,
          jersey: b.jersey ? Number(b.jersey) : null,
          category: b.category === "ACADEMY" ? "ACADEMY" : "FIRST",
          insurance: "NONE",
          /* 📷 عکس بازیکن که مالک باشگاه آپلود کرده */
          photo: String(b.photo ?? "") || null,
        });
        return Response.json({ ok: true });
      }

      case "player:insurance": {
        const status = b.insurance === "VALID" ? "VALID" : b.insurance === "EXPIRED" ? "EXPIRED" : "NONE";
        await db.update(players).set({ insurance: status, insuranceExpiry: String(b.expiry ?? "") || null }).where(eq(players.id, Number(b.id)));
        return Response.json({ ok: true });
      }

      case "player:delete": {
        await db.delete(players).where(eq(players.id, Number(b.id)));
        return Response.json({ ok: true });
      }

      case "transfer:request": {
        const playerName = String(b.playerName ?? "").trim();
        const toClub = String(b.toClub ?? "").trim();
        if (!playerName || !toClub) return Response.json({ error: "نام بازیکن و باشگاه مقصد الزامی است." }, { status: 400 });
        const [club] = await db.select().from(clubs).where(eq(clubs.id, auth.clubId)).limit(1);
        await db.insert(transfers).values({
          playerName,
          fromClub: club?.name ?? "—",
          toClub,
          kind: b.kind === "RELEASE" ? "RELEASE" : "TRANSFER",
          status: "PENDING",
          clubId: auth.clubId,
        });
        return Response.json({ ok: true });
      }

      default:
        return Response.json({ error: "عملیات نامعتبر" }, { status: 400 });
    }
  } catch (e) {
    console.error("club action error", e);
    return Response.json({ error: "خطای سرور" }, { status: 500 });
  }
}
