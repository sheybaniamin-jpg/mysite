import { db } from "@/db";
import {
  clubs,
  courseEnrollments,
  courses,
  disciplineCases,
  futsalSignups,
  galleryItems,
  matchEvents,
  matches,
  news,
  players,
  referees,
  talentRegs,
  transfers,
  veterans,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { getAdminBundle } from "@/lib/data";
import { clearAllData, seedDemoData } from "@/lib/seed";
import { randomPassword, slugify } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await requireAdmin())) return Response.json({ error: "دسترسی غیرمجاز" }, { status: 401 });
  return Response.json(await getAdminBundle());
}

export async function POST(req: Request) {
  if (!(await requireAdmin())) return Response.json({ error: "دسترسی غیرمجاز" }, { status: 401 });
  const b = await req.json();
  const action: string = b?.action ?? "";

  try {
    switch (action) {
      // ─── داده آزمایشی ───
      case "seed:reset": {
        await clearAllData();
        await seedDemoData();
        return Response.json({ ok: true, message: "داده آزمایشی با موفقیت بازسازی شد." });
      }

      // ─── باشگاه‌ها ───
      case "club:approve": {
        const id = Number(b.id);
        const [club] = await db.select().from(clubs).where(eq(clubs.id, id)).limit(1);
        if (!club) return Response.json({ error: "باشگاه یافت نشد." }, { status: 404 });
        const username = club.username || `${slugify(club.name).slice(0, 12)}-${Math.floor(10 + Math.random() * 89)}`;
        const password = randomPassword(8);
        await db.update(clubs).set({ status: "APPROVED", username, password }).where(eq(clubs.id, id));
        return Response.json({ ok: true, username, password });
      }
      case "club:reject":
        await db.update(clubs).set({ status: "REJECTED" }).where(eq(clubs.id, Number(b.id)));
        return Response.json({ ok: true });
      case "club:suspend":
        await db.update(clubs).set({ status: "SUSPENDED" }).where(eq(clubs.id, Number(b.id)));
        return Response.json({ ok: true });
      case "club:activate":
        await db.update(clubs).set({ status: "APPROVED" }).where(eq(clubs.id, Number(b.id)));
        return Response.json({ ok: true });
      case "club:delete":
        await db.delete(clubs).where(eq(clubs.id, Number(b.id)));
        return Response.json({ ok: true });
      case "club:reset-pass": {
        const id = Number(b.id);
        const password = randomPassword(8);
        await db.update(clubs).set({ password }).where(eq(clubs.id, id));
        return Response.json({ ok: true, password });
      }

      // ─── بانک بازیکنان ───
      case "player:save": {
        const data = {
          clubId: b.clubId ? Number(b.clubId) : null,
          name: String(b.name ?? "").trim(),
          nationalId: String(b.nationalId ?? "") || null,
          birthYear: b.birthYear ? Number(b.birthYear) : null,
          position: String(b.position ?? "") || null,
          jersey: b.jersey ? Number(b.jersey) : null,
          category: b.category === "ACADEMY" ? "ACADEMY" : "FIRST",
          insurance: ["VALID", "EXPIRED", "NONE"].includes(b.insurance) ? b.insurance : "NONE",
          insuranceExpiry: String(b.insuranceExpiry ?? "") || null,
          photo: b.photo !== undefined ? String(b.photo ?? "") || null : undefined,
        };
        if (!data.name) return Response.json({ error: "نام بازیکن الزامی است." }, { status: 400 });
        if (b.id) await db.update(players).set(data).where(eq(players.id, Number(b.id)));
        else await db.insert(players).values(data);
        return Response.json({ ok: true });
      }
      case "player:delete":
        await db.delete(players).where(eq(players.id, Number(b.id)));
        return Response.json({ ok: true });

      // ─── مسابقات ───
      case "match:save": {
        const data = {
          league: ["U8_12", "U12_15", "U15_18", "ADULT", "FUTSAL1"].includes(b.league) ? b.league : "ADULT",
          week: Number(b.week ?? 1),
          homeName: String(b.homeName ?? "").trim(),
          awayName: String(b.awayName ?? "").trim(),
          homeClubId: b.homeClubId ? Number(b.homeClubId) : null,
          awayClubId: b.awayClubId ? Number(b.awayClubId) : null,
          status: ["SCHEDULED", "LIVE", "FINISHED", "POSTPONED"].includes(b.status) ? b.status : "SCHEDULED",
          dateTime: new Date(b.dateTime || Date.now()),
          venue: String(b.venue ?? "") || null,
          refereeId: b.refereeId ? Number(b.refereeId) : null,
          homeScore: b.homeScore !== "" && b.homeScore !== null && b.homeScore !== undefined ? Number(b.homeScore) : null,
          awayScore: b.awayScore !== "" && b.awayScore !== null && b.awayScore !== undefined ? Number(b.awayScore) : null,
        };
        if (!data.homeName || !data.awayName) return Response.json({ error: "نام دو تیم الزامی است." }, { status: 400 });
        if (data.homeName === data.awayName) return Response.json({ error: "دو تیم نمی‌توانند یکسان باشند." }, { status: 400 });
        if (b.id) await db.update(matches).set(data).where(eq(matches.id, Number(b.id)));
        else await db.insert(matches).values(data);
        return Response.json({ ok: true });
      }
      case "match:delete": {
        await db.delete(matchEvents).where(eq(matchEvents.matchId, Number(b.id)));
        await db.delete(matches).where(eq(matches.id, Number(b.id)));
        return Response.json({ ok: true });
      }
      case "event:add": {
        const data = {
          matchId: Number(b.matchId),
          minute: Number(b.minute ?? 1),
          type: ["goal", "penalty", "owngoal", "yellow", "red"].includes(b.type) ? b.type : "goal",
          playerName: String(b.playerName ?? "").trim(),
          side: b.side === "AWAY" ? "AWAY" : "HOME",
          note: String(b.note ?? "") || null,
        };
        if (!data.playerName) return Response.json({ error: "نام بازیکن الزامی است." }, { status: 400 });
        await db.insert(matchEvents).values(data);
        return Response.json({ ok: true });
      }
      case "event:delete":
        await db.delete(matchEvents).where(eq(matchEvents.id, Number(b.id)));
        return Response.json({ ok: true });

      // ─── داوران ───
      case "referee:save": {
        const data = {
          name: String(b.name ?? "").trim(),
          grade: String(b.grade ?? "درجه دو"),
          kind: b.kind === "فوتسال" ? "فوتسال" : "فوتبال",
          city: String(b.city ?? "") || null,
          yearsActive: Number(b.yearsActive ?? 0),
          matchesCount: Number(b.matchesCount ?? 0),
          active: b.active !== false,
        };
        if (!data.name) return Response.json({ error: "نام داور الزامی است." }, { status: 400 });
        if (b.id) await db.update(referees).set(data).where(eq(referees.id, Number(b.id)));
        else await db.insert(referees).values(data);
        return Response.json({ ok: true });
      }
      case "referee:delete":
        await db.delete(referees).where(eq(referees.id, Number(b.id)));
        return Response.json({ ok: true });
      case "fsignup:delete":
        await db.delete(futsalSignups).where(eq(futsalSignups.id, Number(b.id)));
        return Response.json({ ok: true });

      // ─── اخبار ───
      case "news:save": {
        const title = String(b.title ?? "").trim();
        if (!title) return Response.json({ error: "عنوان خبر الزامی است." }, { status: 400 });
        const common = {
          title,
          category: String(b.category ?? "اخبار هیئت"),
          excerpt: String(b.excerpt ?? ""),
          body: String(b.body ?? ""),
          image: String(b.image ?? "") || null,
          tags: (b.tags ?? "") === "" ? [] : String(b.tags).split("،").map((t: string) => t.trim()),
          featured: b.featured === true,
        };
        if (b.id) await db.update(news).set(common).where(eq(news.id, Number(b.id)));
        else await db.insert(news).values({ ...common, slug: slugify(title) + "-" + Date.now().toString().slice(-5) });
        return Response.json({ ok: true });
      }
      case "news:delete":
        await db.delete(news).where(eq(news.id, Number(b.id)));
        return Response.json({ ok: true });

      // ─── دوره‌ها ───
      case "course:save": {
        const title = String(b.title ?? "").trim();
        if (!title) return Response.json({ error: "عنوان دوره الزامی است." }, { status: 400 });
        const data = {
          title,
          kind: String(b.kind ?? "عمومی"),
          instructor: String(b.instructor ?? "") || null,
          startDate: String(b.startDate ?? "") || null,
          capacity: Number(b.capacity ?? 30),
          location: String(b.location ?? "") || null,
          fee: String(b.fee ?? "") || null,
          status: ["open", "closed", "finished"].includes(b.status) ? b.status : "open",
          description: String(b.description ?? ""),
        };
        if (b.id) await db.update(courses).set(data).where(eq(courses.id, Number(b.id)));
        else await db.insert(courses).values(data);
        return Response.json({ ok: true });
      }
      case "course:delete":
        await db.delete(courses).where(eq(courses.id, Number(b.id)));
        return Response.json({ ok: true });

      // ─── گالری ───
      case "gallery:save": {
        const title = String(b.title ?? "").trim();
        const url = String(b.url ?? "").trim();
        if (!title || !url) return Response.json({ error: "عنوان و آدرس تصویر الزامی است." }, { status: 400 });
        if (b.id) await db.update(galleryItems).set({ title, url, category: String(b.category ?? "") || null }).where(eq(galleryItems.id, Number(b.id)));
        else await db.insert(galleryItems).values({ title, url, kind: "IMAGE", category: String(b.category ?? "") || null });
        return Response.json({ ok: true });
      }
      case "gallery:delete":
        await db.delete(galleryItems).where(eq(galleryItems.id, Number(b.id)));
        return Response.json({ ok: true });

      // ─── پیشکسوتان ───
      case "veteran:save": {
        const name = String(b.name ?? "").trim();
        if (!name) return Response.json({ error: "نام پیشکسوت الزامی است." }, { status: 400 });
        const data = {
          name,
          era: String(b.era ?? "") || null,
          role: String(b.role ?? "") || null,
          bio: String(b.bio ?? ""),
          achievements: String(b.achievements ?? "") || null,
        };
        if (b.id) await db.update(veterans).set(data).where(eq(veterans.id, Number(b.id)));
        else await db.insert(veterans).values(data);
        return Response.json({ ok: true });
      }
      case "veteran:delete":
        await db.delete(veterans).where(eq(veterans.id, Number(b.id)));
        return Response.json({ ok: true });

      // ─── انضباطی ───
      case "discipline:save": {
        const subject = String(b.subject ?? "").trim();
        const verdict = String(b.verdict ?? "").trim();
        if (!subject || !verdict) return Response.json({ error: "موضوع و رأی الزامی است." }, { status: 400 });
        const data = {
          caseNo: String(b.caseNo ?? "").trim() || `انضباطی-${Date.now().toString().slice(-6)}`,
          date: String(b.date ?? "") || new Intl.DateTimeFormat("fa-IR").format(new Date()),
          clubName: String(b.clubName ?? "") || null,
          playerName: String(b.playerName ?? "") || null,
          subject,
          verdict,
          kind: String(b.kind ?? "") || null,
        };
        if (b.id) await db.update(disciplineCases).set(data).where(eq(disciplineCases.id, Number(b.id)));
        else await db.insert(disciplineCases).values(data);
        return Response.json({ ok: true });
      }
      case "discipline:delete":
        await db.delete(disciplineCases).where(eq(disciplineCases.id, Number(b.id)));
        return Response.json({ ok: true });

      // ─── نقل و انتقالات ───
      case "transfer:set":
        await db.update(transfers).set({ status: b.status === "APPROVED" ? "APPROVED" : b.status === "REJECTED" ? "REJECTED" : "PENDING" }).where(eq(transfers.id, Number(b.id)));
        return Response.json({ ok: true });

      default:
        return Response.json({ error: "عملیات نامعتبر" }, { status: 400 });
    }
  } catch (e) {
    console.error("admin action error", e);
    return Response.json({ error: "خطای سرور" }, { status: 500 });
  }
}
