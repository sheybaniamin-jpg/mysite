import { db } from "@/db";
import { clubs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { clearSessionCookie, encodeSession, getSession, setSessionCookie, verifyAdminKey } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const s = await getSession();
  if (!s) return Response.json({ error: "وارد نشده‌اید." }, { status: 401 });
  return Response.json({ ok: true, role: s.role, name: s.role === "club" ? s.name : undefined });
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const action = body?.action as string;

    if (action === "admin-login") {
      if (verifyAdminKey(String(body.key ?? ""))) {
        const token = encodeSession({ role: "admin" });
        await setSessionCookie(token);
        return Response.json({ ok: true, token });
      }
      return Response.json({ error: "کلید محرمانه نامعتبر است." }, { status: 401 });
    }

    if (action === "club-login") {
      const username = String(body.username ?? "").trim();
      const password = String(body.password ?? "");
      if (!username || !password) {
        return Response.json({ error: "نام کاربری و رمز عبور را وارد کنید." }, { status: 400 });
      }
      const [club] = await db.select().from(clubs).where(eq(clubs.username, username)).limit(1);
      if (!club || club.password !== password) {
        return Response.json({ error: "نام کاربری یا رمز عبور اشتباه است." }, { status: 401 });
      }
      if (club.status !== "APPROVED") {
        return Response.json({ error: "حساب باشگاه هنوز توسط هیئت تأیید نشده است." }, { status: 403 });
      }
      const token = encodeSession({ role: "club", clubId: club.id, name: club.name });
      await setSessionCookie(token);
      return Response.json({ ok: true, token });
    }

    if (action === "logout") {
      await clearSessionCookie();
      return Response.json({ ok: true });
    }

    return Response.json({ error: "عملیات نامعتبر" }, { status: 400 });
  } catch {
    return Response.json({ error: "خطای سرور" }, { status: 500 });
  }
}
