import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

/*
  آپلود عکس (مثل عکس بازیکن)
  کلاینت فایل را به‌صورت Data URL می‌فرستد و سرور آن را
  در پوشه‌ی عمومی  public/uploads  ذخیره می‌کند تا با آدرس
  مستقیم قابل نمایش باشد.
*/
export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return Response.json({ error: "ابتدا وارد شوید." }, { status: 401 });

  try {
    const b = await req.json();
    const dataUrl = String(b.dataUrl ?? "");
    const fileName = String(b.fileName ?? "image");

    const m = dataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
    if (!m) return Response.json({ error: "فقط فایل تصویری مجاز است." }, { status: 400 });
    if (m[2].length > 6 * 1024 * 1024) {
      return Response.json({ error: "حجم عکس نباید بیشتر از ۴ مگابایت باشد." }, { status: 400 });
    }

    const extMap: Record<string, string> = {
      "image/jpeg": ".jpg",
      "image/jpg": ".jpg",
      "image/png": ".png",
      "image/webp": ".webp",
      "image/gif": ".gif",
    };
    const ext = extMap[m[1].toLowerCase()] ?? ".jpg";
    const safeBase = fileName.replace(/\.[a-z0-9]+$/i, "").replace(/[^\w\u0600-\u06FF-]+/g, "-").slice(0, 40) || "image";
    const name = `${Date.now()}-${safeBase}${ext}`;

    const dir = path.join(process.cwd(), "uploads");
    await mkdir(dir, { recursive: true });
    await writeFile(path.join(dir, name), Buffer.from(m[2], "base64"));

    /* فایل از طریق مسیر اختصاصی زیر سرو می‌شود (بدون نیاز به ری‌استارت) */
    return Response.json({ ok: true, url: `/api/file/${name}` });
  } catch (e) {
    console.error("upload error", e);
    return Response.json({ error: "خطا در ذخیره عکس." }, { status: 500 });
  }
}
