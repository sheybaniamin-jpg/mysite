import { readFile } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

const TYPES: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".gif": "image/gif",
};

/* نمایش فایل‌های آپلودشده (عکس بازیکنان و…) از پوشه‌ی آپلود سرور */
export async function GET(_req: Request, ctx: { params: Promise<{ name: string }> }) {
  const { name } = await ctx.params;
  /* جلوگیری از دسترسی به مسیرهای دیگر */
  if (!/^[\w\u0600-\u06FF.-]+$/.test(name) || name.includes("..")) {
    return Response.json({ error: "نام فایل نامعتبر است." }, { status: 400 });
  }
  try {
    const file = path.join(process.cwd(), "uploads", name);
    const buf = await readFile(file);
    const type = TYPES[path.extname(name).toLowerCase()] ?? "application/octet-stream";
    return new Response(buf, {
      headers: { "Content-Type": type, "Cache-Control": "public, max-age=86400" },
    });
  } catch {
    return Response.json({ error: "فایل یافت نشد." }, { status: 404 });
  }
}
