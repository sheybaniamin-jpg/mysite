import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async rewrites() {
    return [
      // صفحه اصلی سایت: سرو کردن فایل خالص index.html
      { source: "/", destination: "/index.html" },
    ];
  },
};

export default nextConfig;
