<?php
/* ═══ صفحه عیب‌یابی ═══  آدرس: check.php */
require_once dirname(__FILE__) . '/config.php';
require_once dirname(__FILE__) . '/db.php';
require_once dirname(__FILE__) . '/auth.php';

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/* ─── عملیات POST ─── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    $b = json_decode(file_get_contents('php://input'), true);
    if (!is_array($b)) $b = array();
    $action = isset($b['action']) ? $b['action'] : '';

    if ($action === 'test-key') {
        $ok = hash_equals(PANEL_PASSWORD, isset($b['key']) ? (string)$b['key'] : '');
        echo json_encode(array('ok' => $ok, 'error' => $ok ? '' : 'این رمز با PANEL_PASSWORD در فایل config.php یکی نیست.'), JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'reseed') {
        if (!hash_equals(PANEL_PASSWORD, isset($b['key']) ? (string)$b['key'] : '')) {
            echo json_encode(array('error' => 'رمز اشتباه است.'), JSON_UNESCAPED_UNICODE);
            exit;
        }
        try {
            $pdo = db();
            $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
            foreach (array('match_events','matches','course_enrollments','courses','players','clubs','referees') as $t) $pdo->exec("TRUNCATE TABLE `$t`");
            $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
            $clubs = array(
                array('زرین','images/zarin.png','zr1404kp'), array('جزیره','images/jazire.jpg','jz2481mq'), array('نود','images/navad.jpg','nv7359xt'),
                array('ایریا شوکت','images/ayriashokat.jpg','ay5127rd'), array('مهرعظام','images/mehrezam.jpg','mh8642sf'), array('بهراد','images/behrad.webp','bh3965lk'),
                array('ایران مهر','images/iranmehr.jpg','im1793qw'), array('نوین','images/novin.jpg','no4826zp'), array('جاویدان','images/javidan.jpg','jv6254tc'),
                array('ملک','images/malek.jpg','mk9318gh'), array('سرخ پوشان','images/sorkposhan.jpg','sr2746bn'), array('ستارگان ایران','images/iranstar.png','is8173vx'),
                array('ستارگان کویر','images/setaregankavir.jpg','st5931pm'), array('جوان پارس','images/javanpars.jpg','jp3587kd'), array('ایران جوان','images/iranjavan.jpg','ij6419fw'),
                array('پیشگامان','images/pishgaman.jpg','ps9253rl'), array('پدیده','images/bahman.jpg','pd4671hm'),
            );
            $st = $pdo->prepare('INSERT INTO clubs (name, owner_name, owner_national_id, owner_phone, activity_type, address, status, username, password, logo) VALUES (?, "—","—","—","فوتبال","بیرجند","APPROVED",?,?,?)');
            foreach ($clubs as $i => $row) {
                $st->execute(array($row[0], 'club-' . str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT), $row[2], $row[1]));
            }
            $refs = array(
                array('فرهاد حسن پور','فوتبال'), array('مهزیار محمدی پور','فوتبال'), array('حسین آسوده','فوتبال'), array('علی اصغر عدالتی صدر','فوتبال'),
                array('سید مجتبی باقری','فوتبال'), array('سجاد سمایی','فوتبال'), array('علی نی خنجی','فوتبال'), array('خلیل خسروی','فوتبال'),
                array('علی سنجری','فوتبال'), array('عرفان عربی','فوتبال'), array('محمدرضا حمزه ای','فوتبال'), array('مهران خسروی','فوتبال'),
                array('میلاد کدخدا','فوتبال'), array('محمد بهدانی','فوتبال'),
                array('محمود طحان','فوتسال'), array('مهدی ابراهیمی','فوتسال'), array('سید ابوالفضل موسوی','فوتسال'), array('حمیدرضا حاجی پور','فوتسال'),
                array('ابوالفضل جمالی','فوتسال'), array('سید ساجد پور سجادی','فوتسال'), array('بهمن محمدی','فوتسال'), array('ابوالفضل رضایی','فوتسال'),
            );
            $st2 = $pdo->prepare('INSERT INTO referees (name, grade, kind, city) VALUES (?, ?, ?, "بیرجند")');
            foreach ($refs as $i => $row) {
                $grade = ($row[1] === 'فوتسال') ? (($i < 16) ? 'استانی' : 'درجه یک') : (($i < 2) ? 'استانی' : 'درجه یک');
                $st2->execute(array($row[0], $grade, $row[1]));
            }
            echo json_encode(array('ok' => true), JSON_UNESCAPED_UNICODE);
        } catch (Exception $e) {
            echo json_encode(array('error' => 'خطا: ' . $e->getMessage()), JSON_UNESCAPED_UNICODE);
        }
        exit;
    }

    echo json_encode(array('error' => 'عملیات نامعتبر'), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ─── جمع‌آوری وضعیت ─── */
$checks = array();
$clubs = array();

try {
    $pdo = db();
    $pdo->query('SELECT 1');
    $checks['db'] = array('ok' => true, 'msg' => 'اتصال به دیتابیس برقرار است (' . DB_NAME . ')');

    $tables = array('clubs','players','matches','match_events','referees','news','courses','course_enrollments','gallery_items','veterans','discipline_cases','transfers','talent_regs','futsal_signups');
    $missing = array();
    foreach ($tables as $t) {
        $r = $pdo->query("SHOW TABLES LIKE '$t'")->fetchColumn();
        if (!$r) $missing[] = $t;
    }
    $checks['tables'] = $missing
        ? array('ok' => false, 'msg' => 'جدول‌های گم‌شده: ' . implode(', ', $missing) . ' — فایل database.sql را در phpMyAdmin ایمپورت کنید')
        : array('ok' => true, 'msg' => 'هر ۱۴ جدول وجود دارد');

    $clubs = $pdo->query('SELECT id,name,status,username,password FROM clubs ORDER BY id')->fetchAll();
    $checks['clubs'] = count($clubs)
        ? array('ok' => true, 'msg' => count($clubs) . ' باشگاه در دیتابیس ثبت شده')
        : array('ok' => false, 'msg' => 'هیچ باشگاهی در دیتابیس نیست — از دکمه «ساخت باشگاه‌ها» در پایین استفاده کنید');

    $refsCount = (int)$pdo->query('SELECT COUNT(*) FROM referees')->fetchColumn();
    $checks['refs'] = array('ok' => $refsCount > 0, 'msg' => $refsCount . ' داور ثبت شده');
} catch (Exception $e) {
    $checks['db'] = array('ok' => false, 'msg' => 'اتصال به دیتابیس برقرار نشد: ' . $e->getMessage() . ' — مقادیر config.php را بررسی کنید');
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>عیب‌یابی | هیئت فوتبال بیرجند</title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700;900&display=swap" rel="stylesheet" />
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: "Vazirmatn", Tahoma, sans-serif; background: #060f1e; color: #eef3fa; padding: 24px; line-height: 1.9; }
  .wrap { max-width: 860px; margin: 0 auto; }
  h1 { font-size: 22px; margin-bottom: 6px; }
  .sub { color: #84a3cd; font-size: 13px; margin-bottom: 22px; }
  .card { background: #10213d; border: 1px solid #24406c; border-radius: 14px; padding: 18px 20px; margin-bottom: 16px; }
  .card h2 { font-size: 15px; margin-bottom: 12px; color: #f5cf68; }
  .ok { color: #34d37f; font-weight: 700; }
  .bad { color: #f87171; font-weight: 700; }
  .row { display: flex; gap: 8px; align-items: center; padding: 6px 0; font-size: 13.5px; border-bottom: 1px dashed #24406c; flex-wrap: wrap; }
  .row:last-child { border-bottom: none; }
  table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
  th { background: #192f53; padding: 8px; text-align: right; }
  td { padding: 7px 8px; border-bottom: 1px solid #192f53; }
  .mono { font-family: monospace; direction: ltr; display: inline-block; background: #060f1e; padding: 1px 8px; border-radius: 6px; color: #f5cf68; }
  input { width: 100%; padding: 10px 14px; border-radius: 10px; border: 1px solid #24406c; background: #060f1e; color: #eef3fa; font-family: inherit; font-size: 13px; }
  button { padding: 10px 22px; border-radius: 10px; border: none; background: #069a4e; color: #fff; font-family: inherit; font-weight: 700; cursor: pointer; font-size: 13px; }
  button.red { background: #dc2626; }
  button.navy { background: #24406c; }
  .msg { margin-top: 10px; font-size: 13px; }
  a { color: #34d37f; }
</style>
</head>
<body>
<div class="wrap">
  <h1>🔧 عیب‌یابی سامانه هیئت فوتبال بیرجند</h1>
  <div class="sub">وضعیت سرور، دیتابیس و حساب‌ها. بعد از رفع مشکل می‌توانید این فایل را حذف کنید.</div>

  <div class="card">
    <h2>۱) وضعیت سرور و دیتابیس</h2>
    <div class="row"><span>نسخه PHP:</span> <b><?php echo h(PHP_VERSION); ?></b> <?php echo version_compare(PHP_VERSION, '7.0.0', '>=') ? '<span class="ok">✅ مناسب است</span>' : '<span class="bad">❌ حداقل PHP 7.0 لازم است</span>'; ?></div>
    <?php foreach ($checks as $c): ?>
      <div class="row"><span><?php echo $c['ok'] ? '<span class="ok">✅</span>' : '<span class="bad">❌</span>'; ?></span> <?php echo h($c['msg']); ?></div>
    <?php endforeach; ?>
  </div>

  <div class="card">
    <h2>۲) حساب‌های باشگاه (مستقیم از دیتابیس)</h2>
    <?php if (count($clubs)): ?>
      <table>
        <tr><th>#</th><th>باشگاه</th><th>نام کاربری</th><th>رمز عبور</th><th>وضعیت</th></tr>
        <?php foreach ($clubs as $c): ?>
          <tr>
            <td><?php echo h($c['id']); ?></td>
            <td><?php echo h($c['name']); ?></td>
            <td><span class="mono"><?php echo h($c['username'] ? $c['username'] : '—'); ?></span></td>
            <td><span class="mono"><?php echo h($c['password'] ? $c['password'] : '—'); ?></span></td>
            <td><?php echo $c['status'] === 'APPROVED' ? '<span class="ok">فعال</span>' : h($c['status']); ?></td>
          </tr>
        <?php endforeach; ?>
      </table>
      <div class="msg">با همین نام کاربری/رمز وارد <a href="club-login.html">پنل باشگاه‌ها</a> شوید.</div>
    <?php else: ?>
      <div class="msg bad">باشگاهی ثبت نشده است. رمز پنل را وارد کنید و دکمه زیر را بزنید تا ۱۷ باشگاه و ۲۲ داور ساخته شود:</div>
      <div style="display:flex;gap:10px;margin-top:10px;flex-wrap:wrap">
        <input id="reseed-key" type="text" placeholder="رمز ورود پنل‌ها" style="flex:1;min-width:220px" />
        <button class="red" id="reseed-btn">ساخت باشگاه‌ها و داوران</button>
      </div>
      <div class="msg" id="reseed-msg"></div>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>۳) ورود مدیر (تست رمز + ورود)</h2>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <input id="admin-key" type="password" placeholder="رمز ورود پنل‌ها (PANEL_PASSWORD)" style="flex:1;min-width:220px" />
      <button class="navy" id="test-btn">تست کلید</button>
      <button id="admin-login-btn">ورود به پنل مدیر</button>
    </div>
    <div class="msg" id="admin-msg"></div>
  </div>

  <div class="card">
    <h2>۴) لینک‌ها</h2>
    <div class="row">🌐 <a href="index.html">صفحه اصلی سایت</a></div>
    <div class="row">🛡 <a href="admin-login.html">ورود مدیر</a></div>
    <div class="row">🏟 <a href="club-login.html">ورود باشگاه‌ها</a></div>
    <div class="row">⚙️ <a href="api/auth.php">تست بک‌اند</a> — باید پیام «وارد نشده‌اید» نشان دهد</div>
  </div>
</div>

<script>
  function show(id, text, ok) {
    var el = document.getElementById(id);
    el.textContent = text;
    el.className = "msg " + (ok ? "ok" : "bad");
  }
  document.getElementById("test-btn").addEventListener("click", function () {
    var key = document.getElementById("admin-key").value;
    fetch("check.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "test-key", key: key }) })
      .then(function (r) { return r.json(); })
      .then(function (d) { show("admin-msg", d.ok ? "✅ کلید درست است — با همین کلید وارد شوید" : "❌ " + d.error, d.ok); })
      .catch(function (e) { show("admin-msg", "خطا در ارتباط با سرور: " + e.message, false); });
  });
  document.getElementById("admin-login-btn").addEventListener("click", function () {
    var key = document.getElementById("admin-key").value;
    fetch("api/login.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password: key, mode: "admin" }) })
      .then(function (r) { return r.json().then(function (d) { return { r: r, d: d }; }); })
      .then(function (x) {
        if (!x.r.ok || !x.d.ok) { show("admin-msg", "❌ " + (x.d.error || "خطا (کد " + x.r.status + ")"), false); return; }
        localStorage.setItem("panel_token", x.d.token);
        show("admin-msg", "✅ ورود موفق — در حال انتقال…", true);
        setTimeout(function () { location.href = "admin.html"; }, 600);
      })
      .catch(function (e) { show("admin-msg", "خطا در ارتباط با سرور: " + e.message, false); });
  });
  var rb = document.getElementById("reseed-btn");
  if (rb) rb.addEventListener("click", function () {
    var key = document.getElementById("reseed-key").value;
    rb.disabled = true;
    fetch("check.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "reseed", key: key }) })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d.ok) { show("reseed-msg", "✅ باشگاه‌ها و داوران ساخته شدند — صفحه را رفرش کنید", true); }
        else { show("reseed-msg", "❌ " + d.error, false); rb.disabled = false; }
      })
      .catch(function (e) { show("reseed-msg", "خطا: " + e.message, false); rb.disabled = false; });
  });
</script>
</body>
</html>
