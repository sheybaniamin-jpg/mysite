<?php
/* ═══════════════════════════════════════════════════════════
   ⚙️ تنظیمات سامانه هیئت فوتبال بیرجند
   ═══════════════════════════════════════════════════════════ */

/* ─── مشخصات دیتابیس MySQL ─── */
define('DB_HOST', 'localhost');
define('DB_NAME', 'birjir_heeyatfootball');
define('DB_USER', 'birjir_heeyat_admin');
define('DB_PASS', 'heeyatdatabasepasswordfaghatmadarimesh!!#');

/* ─── 🔑 رمز ورود مدیر هیئت (تنها رمز مدیر — همین یک مقدار) ───
   برای تغییر رمز مدیر فقط همین مقدار را عوض کنید. */
define('PANEL_PASSWORD', 'birjand1404');

/* سازگار با کدهای قدیمی — دیگر استفاده نمی‌شود و با رمز مدیر یکسان است */
define('ADMIN_KEY', PANEL_PASSWORD);

/* ─── کلید امضای توکن‌های نشست ─── */
define('TOKEN_SECRET', 'bfa-heeyat-birjand-secret-1404');

/* ─── حالت عیب‌یابی ───
   وقتی 1 باشد خطاها کامل نمایش داده می‌شود (برای پیدا کردن مشکل).
   بعد از درست شدن سایت، حتماً 0 کنید. */
define('DEBUG_MODE', 1);

/* ─── پوشه ذخیره عکس‌های آپلودشده ─── */
define('UPLOAD_DIR', dirname(__FILE__) . '/uploads');

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
}
