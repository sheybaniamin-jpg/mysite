-- ═══════════════════════════════════════════════════════════
-- دیتابیس سامانه هیئت فوتبال شهرستان بیرجند (MySQL)
-- نحوه استفاده: در سی‌پنل یک دیتابیس بسازید، سپس این فایل را
-- از طریق phpMyAdmin (تب Import) روی همان دیتابیس وارد کنید.
-- ═══════════════════════════════════════════════════════════

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- برای ایمپورت تمیز، جدول‌های قبلی حذف می‌شوند
DROP TABLE IF EXISTS `match_events`;
DROP TABLE IF EXISTS `course_enrollments`;
DROP TABLE IF EXISTS `players`;
DROP TABLE IF EXISTS `matches`;
DROP TABLE IF EXISTS `clubs`;
DROP TABLE IF EXISTS `referees`;
DROP TABLE IF EXISTS `news`;
DROP TABLE IF EXISTS `courses`;
DROP TABLE IF EXISTS `gallery_items`;
DROP TABLE IF EXISTS `veterans`;
DROP TABLE IF EXISTS `discipline_cases`;
DROP TABLE IF EXISTS `transfers`;
DROP TABLE IF EXISTS `talent_regs`;
DROP TABLE IF EXISTS `futsal_signups`;

-- ─── باشگاه‌ها ───
CREATE TABLE IF NOT EXISTS `clubs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `owner_name` VARCHAR(150) NOT NULL DEFAULT '—',
  `owner_national_id` VARCHAR(20) NOT NULL DEFAULT '—',
  `owner_phone` VARCHAR(20) NOT NULL DEFAULT '—',
  `activity_type` VARCHAR(60) NOT NULL DEFAULT 'فوتبال',
  `age_group` VARCHAR(40) NULL,
  `license_no` VARCHAR(60) NULL,
  `address` VARCHAR(300) NULL,
  `description` TEXT NULL,
  `status` ENUM('PENDING_APPROVAL','APPROVED','REJECTED','SUSPENDED') NOT NULL DEFAULT 'PENDING_APPROVAL',
  `username` VARCHAR(80) NULL,
  `password` VARCHAR(80) NULL,
  `founded_year` INT NULL,
  `logo` VARCHAR(300) NULL,
  `profile` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_clubs_name` (`name`),
  KEY `idx_clubs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── بازیکنان ───
CREATE TABLE IF NOT EXISTS `players` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `club_id` INT UNSIGNED NULL,
  `name` VARCHAR(150) NOT NULL,
  `national_id` VARCHAR(20) NULL,
  `birth_year` INT NULL,
  `position` VARCHAR(40) NULL,
  `jersey` INT NULL,
  `category` VARCHAR(20) NOT NULL DEFAULT 'FIRST',
  `insurance` VARCHAR(20) NOT NULL DEFAULT 'NONE',
  `insurance_expiry` VARCHAR(20) NULL,
  `photo` VARCHAR(300) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_players_club` (`club_id`),
  CONSTRAINT `fk_players_club` FOREIGN KEY (`club_id`) REFERENCES `clubs`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── داوران ───
CREATE TABLE IF NOT EXISTS `referees` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `grade` VARCHAR(40) NOT NULL DEFAULT 'درجه دو',
  `kind` VARCHAR(20) NOT NULL DEFAULT 'فوتبال',
  `city` VARCHAR(80) NULL,
  `years_active` INT NOT NULL DEFAULT 0,
  `matches_count` INT NOT NULL DEFAULT 0,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── مسابقات ───
CREATE TABLE IF NOT EXISTS `matches` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `league` VARCHAR(30) NOT NULL,
  `week` INT NOT NULL DEFAULT 1,
  `home_name` VARCHAR(150) NOT NULL,
  `away_name` VARCHAR(150) NOT NULL,
  `home_club_id` INT UNSIGNED NULL,
  `away_club_id` INT UNSIGNED NULL,
  `home_score` INT NULL,
  `away_score` INT NULL,
  `status` ENUM('SCHEDULED','LIVE','FINISHED','POSTPONED') NOT NULL DEFAULT 'SCHEDULED',
  `date_time` DATETIME NOT NULL,
  `venue` VARCHAR(150) NULL,
  `referee_id` INT UNSIGNED NULL,
  `attendance` INT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_matches_league` (`league`),
  KEY `idx_matches_status` (`status`),
  KEY `idx_matches_date` (`date_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── رویدادهای مسابقه ───
CREATE TABLE IF NOT EXISTS `match_events` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `match_id` INT UNSIGNED NOT NULL,
  `minute` INT NOT NULL,
  `type` VARCHAR(20) NOT NULL,
  `player_name` VARCHAR(150) NOT NULL,
  `side` VARCHAR(10) NOT NULL,
  `note` VARCHAR(300) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_events_match` (`match_id`),
  CONSTRAINT `fk_events_match` FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── اخبار ───
CREATE TABLE IF NOT EXISTS `news` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug` VARCHAR(250) NOT NULL,
  `title` VARCHAR(300) NOT NULL,
  `category` VARCHAR(60) NOT NULL,
  `excerpt` TEXT NULL,
  `body` LONGTEXT NULL,
  `image` VARCHAR(400) NULL,
  `tags` JSON NULL,
  `featured` TINYINT(1) NOT NULL DEFAULT 0,
  `views` INT NOT NULL DEFAULT 0,
  `published_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_news_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── دوره‌های آموزشی ───
CREATE TABLE IF NOT EXISTS `courses` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(200) NOT NULL,
  `kind` VARCHAR(40) NOT NULL,
  `instructor` VARCHAR(150) NULL,
  `start_date` VARCHAR(30) NULL,
  `capacity` INT NOT NULL DEFAULT 30,
  `enrolled` INT NOT NULL DEFAULT 0,
  `location` VARCHAR(200) NULL,
  `fee` VARCHAR(80) NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'open',
  `description` TEXT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `course_enrollments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` INT UNSIGNED NULL,
  `name` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `national_id` VARCHAR(20) NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_enroll_status` (`status`),
  CONSTRAINT `fk_enroll_course` FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── گالری ───
CREATE TABLE IF NOT EXISTS `gallery_items` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(200) NOT NULL,
  `kind` VARCHAR(20) NOT NULL DEFAULT 'IMAGE',
  `url` VARCHAR(500) NOT NULL,
  `category` VARCHAR(60) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── پیشکسوتان ───
CREATE TABLE IF NOT EXISTS `veterans` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `era` VARCHAR(60) NULL,
  `role` VARCHAR(60) NULL,
  `bio` TEXT NULL,
  `achievements` TEXT NULL,
  `photo` VARCHAR(300) NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── کمیته انضباطی ───
CREATE TABLE IF NOT EXISTS `discipline_cases` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `case_no` VARCHAR(80) NOT NULL,
  `date` VARCHAR(30) NOT NULL,
  `club_name` VARCHAR(150) NULL,
  `player_name` VARCHAR(150) NULL,
  `subject` VARCHAR(400) NOT NULL,
  `verdict` TEXT NOT NULL,
  `kind` VARCHAR(40) NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── نقل و انتقالات ───
CREATE TABLE IF NOT EXISTS `transfers` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `player_name` VARCHAR(150) NOT NULL,
  `from_club` VARCHAR(150) NOT NULL,
  `to_club` VARCHAR(150) NOT NULL,
  `kind` VARCHAR(20) NOT NULL DEFAULT 'TRANSFER',
  `status` ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  `club_id` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── استعدادیابی ───
CREATE TABLE IF NOT EXISTS `talent_regs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `birth_year` INT NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `city` VARCHAR(80) NULL,
  `position` VARCHAR(40) NULL,
  `note` VARCHAR(400) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── ثبت‌نام لیگ‌های فوتسال (مثل لیگ ادارات) ───
CREATE TABLE IF NOT EXISTS `futsal_signups` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `league` VARCHAR(30) NOT NULL DEFAULT 'F_EDARAT',
  `team_name` VARCHAR(150) NOT NULL,
  `contact_name` VARCHAR(150) NULL,
  `phone` VARCHAR(20) NOT NULL,
  `note` VARCHAR(400) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ═══════════════════════════════════════════════════════════
-- داده‌های اولیه: ۱۷ باشگاه فوتبال + ۲۲ داور
-- (نام‌های کاربری club-01 تا club-17 — رمزها را می‌توانید از
--  پنل مدیریت با دکمه «رمز جدید» تغییر دهید)
-- ═══════════════════════════════════════════════════════════

-- رمز هر باشگاه را «پنل مدیر هیئت» صادر/تعریف می‌کند و در جدول باشگاه‌ها دیده و تغییر می‌دهد.
-- رده سنی خالی یعنی «حضور در همه رده‌ها».
INSERT INTO `clubs` (`name`,`owner_name`,`owner_national_id`,`owner_phone`,`activity_type`,`age_group`,`address`,`status`,`username`,`password`,`logo`) VALUES
('زرین','—','—','—','فوتبال','','بیرجند','APPROVED','club-01','zr4k8m2p','images/zarin.png'),
('جزیره','—','—','—','فوتبال','','بیرجند','APPROVED','club-02','jz7n3q9x','images/jazire.jpg'),
('نود','—','—','—','فوتبال','','بیرجند','APPROVED','club-03','nv2b6t5w','images/navad.jpg'),
('ایریا شوکت','—','—','—','فوتبال','','بیرجند','APPROVED','club-04','ay8d4r7k','images/ayriashokat.jpg'),
('مهرعظام','—','—','—','فوتبال','','بیرجند','APPROVED','club-05','mh5f9j3p','images/mehrezam.jpg'),
('بهراد','—','—','—','فوتبال','','بیرجند','APPROVED','club-06','bh3g7m6s','images/behrad.webp'),
('ایران مهر','—','—','—','فوتبال','','بیرجند','APPROVED','club-07','im6h2n8t','images/iranmehr.jpg'),
('نوین','—','—','—','فوتبال','','بیرجند','APPROVED','club-08','no9k5p4w','images/novin.jpg'),
('جاویدان','—','—','—','فوتبال','','بیرجند','APPROVED','club-09','jd4m8r2x','images/javidan.jpg'),
('ملک','—','—','—','فوتبال','','بیرجند','APPROVED','club-10','mk7n3t6b','images/malek.jpg'),
('سرخ پوشان','—','—','—','فوتبال','','بیرجند','APPROVED','club-11','sr5p9w8d','images/sorkposhan.jpg'),
('ستارگان ایران','—','—','—','فوتبال','','بیرجند','APPROVED','club-12','si8r4x2k','images/iranstar.png'),
('ستارگان کویر','—','—','—','فوتبال','','بیرجند','APPROVED','club-13','sk3t7b5m','images/setaregankavir.jpg'),
('جوان پارس','—','—','—','فوتبال','','بیرجند','APPROVED','club-14','jp6w9d4n','images/javanpars.jpg'),
('ایران جوان','—','—','—','فوتبال','','بیرجند','APPROVED','club-15','ij4x8k3p','images/iranjavan.jpg'),
('پیشگامان','—','—','—','فوتبال','','بیرجند','APPROVED','club-16','ps7b5m9r','images/pishgaman.jpg'),
('پدیده','—','—','—','فوتبال','','بیرجند','APPROVED','club-17','pd9d3n6t','images/bahman.jpg');

INSERT INTO `referees` (`name`,`grade`,`kind`,`city`,`years_active`,`matches_count`,`active`) VALUES
('فرهاد حسن پور','استانی','فوتبال','بیرجند',0,0,1),
('مهزیار محمدی پور','استانی','فوتبال','بیرجند',0,0,1),
('حسین آسوده','استانی','فوتبال','بیرجند',0,0,1),
('علی اصغر عدالتی صدر','درجه یک','فوتبال','بیرجند',0,0,1),
('سید مجتبی باقری','درجه یک','فوتبال','بیرجند',0,0,1),
('سجاد سمایی','درجه یک','فوتبال','بیرجند',0,0,1),
('علی نی خنجی','درجه یک','فوتبال','بیرجند',0,0,1),
('خلیل خسروی','درجه یک','فوتبال','بیرجند',0,0,1),
('علی سنجری','درجه یک','فوتبال','بیرجند',0,0,1),
('عرفان عربی','درجه یک','فوتبال','بیرجند',0,0,1),
('محمدرضا حمزه ای','درجه یک','فوتبال','بیرجند',0,0,1),
('مهران خسروی','درجه یک','فوتبال','بیرجند',0,0,1),
('میلاد کدخدا','درجه یک','فوتبال','بیرجند',0,0,1),
('محمد بهدانی','درجه یک','فوتبال','بیرجند',0,0,1),
('محمود طحان','استانی','فوتسال','بیرجند',0,0,1),
('مهدی ابراهیمی','استانی','فوتسال','بیرجند',0,0,1),
('سید ابوالفضل موسوی','درجه یک','فوتسال','بیرجند',0,0,1),
('حمیدرضا حاجی پور','درجه یک','فوتسال','بیرجند',0,0,1),
('ابوالفضل جمالی','درجه یک','فوتسال','بیرجند',0,0,1),
('سید ساجد پور سجادی','درجه یک','فوتسال','بیرجند',0,0,1),
('بهمن محمدی','درجه یک','فوتسال','بیرجند',0,0,1),
('ابوالفضل رضایی','درجه یک','فوتسال','بیرجند',0,0,1);
