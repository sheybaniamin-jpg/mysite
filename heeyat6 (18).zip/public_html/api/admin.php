<?php
/* ═══ API پنل مدیر ارشد ═══ سازگار با PHP 7.0 به بالا */
require_once dirname(__FILE__) . '/../db.php';
require_once dirname(__FILE__) . '/../auth.php';

header('Content-Type: application/json; charset=utf-8');

function random_password($len = 8) {
    $chars = 'abcdefghjkmnpqrstuvwxyz23456789';
    $out = '';
    for ($i = 0; $i < $len; $i++) $out .= $chars[random_int(0, strlen($chars) - 1)];
    return $out;
}

/* نام کاربری تصادفی انگلیسی (برای جلوگیری از جعل) مانند: bfa-k7m2x9 */
function random_username() {
    $chars = 'abcdefghjkmnpqrstuvwxyz23456789';
    $out = '';
    for ($i = 0; $i < 8; $i++) $out .= $chars[random_int(0, strlen($chars) - 1)];
    return 'bfa-' . $out;
}

/* ساخت نام کاربری یکتا (در صورت تکراری بودن، دوباره می‌سازد) */
function unique_username($pdo) {
    for ($try = 0; $try < 25; $try++) {
        $u = random_username();
        $st = $pdo->prepare('SELECT id FROM clubs WHERE username = ? LIMIT 1');
        $st->execute(array($u));
        if (!$st->fetch()) return $u;
    }
    return 'bfa-' . substr((string)time(), -8);
}

function slugify_admin($s) {
    $s = mb_strtolower(trim($s));
    $s = preg_replace('/[^\p{L}\p{N}]+/u', '-', $s);
    $s = trim($s, '-');
    return $s !== '' ? mb_substr($s, 0, 80) : 'item-' . time();
}

/* داده‌های اولیه: ۱۷ باشگاه + ۲۲ داور */
function seed_data() {
    $pdo = db();
    $clubs = array(
        array('زرین','images/zarin.png'), array('جزیره','images/jazire.jpg'), array('نود','images/navad.jpg'),
        array('ایریا شوکت','images/ayriashokat.jpg'), array('مهرعظام','images/mehrezam.jpg'), array('بهراد','images/behrad.webp'),
        array('ایران مهر','images/iranmehr.jpg'), array('نوین','images/novin.jpg'), array('جاویدان','images/javidan.jpg'),
        array('ملک','images/malek.jpg'), array('سرخ پوشان','images/sorkposhan.jpg'), array('ستارگان ایران','images/iranstar.png'),
        array('ستارگان کویر','images/setaregankavir.jpg'), array('جوان پارس','images/javanpars.jpg'), array('ایران جوان','images/iranjavan.jpg'),
        array('پیشگامان','images/pishgaman.jpg'), array('پدیده','images/bahman.jpg'),
    );
    try {
        $st = $pdo->prepare('INSERT INTO clubs (name, owner_name, owner_national_id, owner_phone, activity_type, age_group, address, status, username, password, logo) VALUES (?, "—","—","—","فوتبال","","بیرجند","APPROVED",?,?,?)');
        foreach ($clubs as $i => $row) {
            $st->execute(array($row[0], unique_username($pdo), random_password(), $row[1]));
        }
    } catch (Exception $e) {
        $st = $pdo->prepare('INSERT INTO clubs (name, owner_name, owner_national_id, owner_phone, activity_type, address, status, username, password, logo) VALUES (?, "—","—","—","فوتبال","بیرجند","APPROVED",?,?,?)');
        foreach ($clubs as $i => $row) {
            $st->execute(array($row[0], unique_username($pdo), random_password(), $row[1]));
        }
    }
    $refs = array(
        array('فرهاد حسن پور','فوتبال'), array('مهزیار محمدی پور','فوتبال'), array('حسین آسوده','فوتبال'), array('علی اصغر عدالتی صدر','فوتبال'),
        array('سید مجتبی باقری','فوتبال'), array('سجاد سمایی','فوتبال'), array('علی نی خنجی','فوتبال'), array('خلیل خسروی','فوتبال'),
        array('علی سنجری','فوتبال'), array('عرفان عربی','فوتبال'), array('محمدرضا حمزه ای','فوتبال'), array('مهران خسروی','فوتبال'),
        array('میلاد کدخدا','فوتبال'), array('محمد بهدانی','فوتبال'),
        array('محمود طحان','فوتسال'), array('مهدی ابراهیمی','فوتسال'), array('سید ابوالفضل موسوی','فوتسال'), array('حمیدرضا حاجی پور','فوتسال'),
        array('ابوالفضل جمالی','فوتسال'), array('سید ساجد پور سجادی','فوتسال'), array('بهمن محمدی','فوتسال'), array('ابوالفضل رضایی','فوتسال'),
    );
    $st2 = $pdo->prepare('INSERT INTO referees (name, grade, kind, city) VALUES (?,?,?, "بیرجند")');
    foreach ($refs as $i => $row) {
        $grade = ($row[1] === 'فوتسال') ? (($i < 16) ? 'استانی' : 'درجه یک') : (($i < 2) ? 'استانی' : 'درجه یک');
        $st2->execute(array($row[0], $grade, $row[1]));
    }
}

try {
    require_admin();
    $pdo = db();

    /* ─────────── GET: بسته کامل ─────────── */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $newsRows = $pdo->query('SELECT * FROM news ORDER BY published_at DESC, id DESC')->fetchAll();
        $newsOut = array();
        foreach ($newsRows as $n) {
            $n['id'] = (int)$n['id']; $n['views'] = (int)$n['views']; $n['featured'] = (bool)$n['featured'];
            $n['tags'] = $n['tags'] ? json_decode($n['tags'], true) : array();
            if (!is_array($n['tags'])) $n['tags'] = array();
            $newsOut[] = $n;
        }
        $map = array();
        foreach ($pdo->query('SELECT * FROM players ORDER BY name')->fetchAll() as $r) $map['players'][] = row_map($r, array('id','club_id','birth_year','jersey'));
        foreach ($pdo->query('SELECT * FROM matches ORDER BY date_time')->fetchAll() as $r) $map['matches'][] = row_map($r, array('id','week','home_club_id','away_club_id','home_score','away_score','referee_id'));
        foreach ($pdo->query('SELECT * FROM match_events')->fetchAll() as $r) $map['events'][] = row_map($r, array('id','match_id','minute'));
        foreach ($pdo->query('SELECT * FROM referees ORDER BY name')->fetchAll() as $r) $map['referees'][] = row_map($r, array('id','years_active','matches_count'));
        foreach ($pdo->query('SELECT * FROM courses')->fetchAll() as $r) $map['courses'][] = row_map($r, array('id','capacity','enrolled'));
        foreach ($pdo->query('SELECT * FROM course_enrollments ORDER BY created_at DESC, id DESC')->fetchAll() as $r) {
            $r = row_map($r, array('id','course_id'));
            $r['status'] = isset($r['status']) && $r['status'] !== '' ? $r['status'] : 'PENDING';
            $map['enrollments'][] = $r;
        }
        foreach ($pdo->query('SELECT * FROM gallery_items ORDER BY created_at DESC')->fetchAll() as $r) $map['gallery'][] = row_map($r, array('id'));
        foreach ($pdo->query('SELECT * FROM veterans')->fetchAll() as $r) $map['veterans'][] = row_map($r, array('id'));
        foreach ($pdo->query('SELECT * FROM discipline_cases ORDER BY id DESC')->fetchAll() as $r) $map['discipline'][] = row_map($r, array('id'));
        foreach ($pdo->query('SELECT * FROM transfers ORDER BY created_at DESC')->fetchAll() as $r) $map['transfers'][] = row_map($r, array('id','club_id'));
        foreach ($pdo->query('SELECT * FROM talent_regs ORDER BY created_at DESC')->fetchAll() as $r) $map['talents'][] = row_map($r, array('id','birth_year'));
        foreach ($pdo->query('SELECT * FROM futsal_signups ORDER BY created_at DESC')->fetchAll() as $r) $map['futsalSignups'][] = row_map($r, array('id'));

        json_out(array(
            'clubs' => $pdo->query('SELECT * FROM clubs ORDER BY name')->fetchAll(),
            'players' => isset($map['players']) ? $map['players'] : array(),
            'matches' => isset($map['matches']) ? $map['matches'] : array(),
            'events' => isset($map['events']) ? $map['events'] : array(),
            'referees' => isset($map['referees']) ? $map['referees'] : array(),
            'news' => $newsOut,
            'courses' => isset($map['courses']) ? $map['courses'] : array(),
            'enrollments' => isset($map['enrollments']) ? $map['enrollments'] : array(),
            'gallery' => isset($map['gallery']) ? $map['gallery'] : array(),
            'veterans' => isset($map['veterans']) ? $map['veterans'] : array(),
            'discipline' => isset($map['discipline']) ? $map['discipline'] : array(),
            'transfers' => isset($map['transfers']) ? $map['transfers'] : array(),
            'talents' => isset($map['talents']) ? $map['talents'] : array(),
            'futsalSignups' => isset($map['futsalSignups']) ? $map['futsalSignups'] : array(),
        ));
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(array('error' => 'روش نامعتبر'), 405);
    $b = read_body();
    $action = isset($b['action']) ? $b['action'] : '';
    $id = (int)(isset($b['id']) ? $b['id'] : 0);

    /* ─── داده اولیه ─── */
    if ($action === 'seed:reset') {
        $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
        foreach (array('match_events','matches','course_enrollments','courses','players','clubs','referees','news','gallery_items','veterans','discipline_cases','transfers','talent_regs','futsal_signups') as $t) {
            $pdo->exec("TRUNCATE TABLE `$t`");
        }
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
        seed_data();
        json_out(array('ok' => true, 'message' => 'داده اولیه با موفقیت بازسازی شد.'));
    }

    /* ─── باشگاه‌ها ─── */
    if ($action === 'newclub') {
        $name = trim(isset($b['name']) ? (string)$b['name'] : '');
        if ($name === '') json_out(array('error' => 'نام باشگاه الزامی است.'), 400);
        $st = $pdo->prepare('SELECT id FROM clubs WHERE name = ? LIMIT 1');
        $st->execute(array($name));
        if ($st->fetch()) json_out(array('error' => 'باشگاهی با این نام وجود دارد.'), 409);
        $approve = !empty($b['approve']);
        $username = $approve ? unique_username($pdo) : null;
        $password = $approve ? random_password() : null;
        $ageGroup = trim(isset($b['ageGroup']) ? (string)$b['ageGroup'] : '');
        $baseNew = array(
            $name,
            trim(isset($b['owner']) ? (string)$b['owner'] : '—'),
            trim(isset($b['phone']) ? (string)$b['phone'] : '—'),
            trim(isset($b['type']) ? (string)$b['type'] : 'فوتبال'),
            $approve ? 'APPROVED' : 'PENDING_APPROVAL',
            $username, $password,
        );
        try {
            $pdo->prepare('INSERT INTO clubs (name, owner_name, owner_national_id, owner_phone, activity_type, age_group, address, status, username, password) VALUES (?, ?, "—", ?, ?, ?, "بیرجند", ?, ?, ?)')
                ->execute(array_merge(array_slice($baseNew, 0, 4), array($ageGroup !== '' ? $ageGroup : null), array_slice($baseNew, 4)));
        } catch (Exception $e) {
            $pdo->prepare('INSERT INTO clubs (name, owner_name, owner_national_id, owner_phone, activity_type, address, status, username, password) VALUES (?, ?, "—", ?, ?, "بیرجند", ?, ?, ?)')
                ->execute($baseNew);
        }
        json_out(array('ok' => true, 'username' => $username, 'password' => $password));
    }
    if ($action === 'talent:delete') {
        $pdo->prepare('DELETE FROM talent_regs WHERE id=?')->execute(array($id));
        json_out(array('ok' => true));
    }
    if ($action === 'club:approve') {
        $st = $pdo->prepare('SELECT * FROM clubs WHERE id = ? LIMIT 1');
        $st->execute(array($id));
        $club = $st->fetch();
        if (!$club) json_out(array('error' => 'باشگاه یافت نشد.'), 404);
        $username = $club['username'] ? $club['username'] : unique_username($pdo);
        $password = random_password();
        $pdo->prepare('UPDATE clubs SET status="APPROVED", username=?, password=? WHERE id=?')->execute(array($username, $password, $id));
        json_out(array('ok' => true, 'username' => $username, 'password' => $password));
    }
    if ($action === 'club:reject') { $pdo->prepare('UPDATE clubs SET status="REJECTED" WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }
    if ($action === 'club:suspend') { $pdo->prepare('UPDATE clubs SET status="SUSPENDED" WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }
    if ($action === 'club:activate') { $pdo->prepare('UPDATE clubs SET status="APPROVED" WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }
    if ($action === 'club:delete') { $pdo->prepare('DELETE FROM clubs WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }
    if ($action === 'clubs:delete-all') {
        /* حذف همه باشگاه‌ها (حتی تأییدشده‌ها)؛ بازیکنان هر باشگاه هم با CASCADE پاک می‌شوند */
        try {
            $pdo->exec('DELETE FROM players');
            $pdo->exec('DELETE FROM clubs');
            json_out(array('ok' => true, 'message' => 'همه باشگاه‌ها حذف شدند.'));
        } catch (Exception $e) {
            json_out(array('error' => 'خطا در حذف باشگاه‌ها: ' . (DEBUG_MODE ? $e->getMessage() : '')), 500);
        }
    }
    if ($action === 'club:set-age') {
        $ag = trim(isset($b['ageGroup']) ? (string)$b['ageGroup'] : '');
        try {
            $pdo->prepare('UPDATE clubs SET age_group=? WHERE id=?')->execute(array($ag !== '' ? $ag : null, $id));
        } catch (Exception $e) {
            json_out(array('error' => 'ستون رده سنی در دیتابیس نیست؛ فایل database.sql را دوباره ایمپورت کنید.'), 400);
        }
        json_out(array('ok' => true));
    }
    if ($action === 'club:reset-pass') {
        $password = random_password();
        $pdo->prepare('UPDATE clubs SET password=? WHERE id=?')->execute(array($password, $id));
        json_out(array('ok' => true, 'password' => $password));
    }

    /* ─── بازیکنان ─── */
    if ($action === 'player:save') {
        if (trim(isset($b['name']) ? (string)$b['name'] : '') === '') json_out(array('error' => 'نام بازیکن الزامی است.'), 400);
        $name = trim((string)$b['name']);
        $nationalId = (isset($b['nationalId']) && trim((string)$b['nationalId']) !== '') ? trim((string)$b['nationalId']) : null;
        $birthYear = !empty($b['birthYear']) ? (int)$b['birthYear'] : null;
        $position = (isset($b['position']) && trim((string)$b['position']) !== '') ? trim((string)$b['position']) : null;
        $jersey = !empty($b['jersey']) ? (int)$b['jersey'] : null;
        $category = (isset($b['category']) && $b['category'] === 'ACADEMY') ? 'ACADEMY' : 'FIRST';
        $insurance = (isset($b['insurance']) && in_array($b['insurance'], array('VALID','EXPIRED','NONE'))) ? $b['insurance'] : 'NONE';
        $expiry = (isset($b['insuranceExpiry']) && trim((string)$b['insuranceExpiry']) !== '') ? trim((string)$b['insuranceExpiry']) : null;
        $photo = array_key_exists('photo', $b) ? ((trim((string)$b['photo']) !== '') ? trim((string)$b['photo']) : null) : null;
        $clubId = !empty($b['clubId']) ? (int)$b['clubId'] : null;
        if ($id) {
            if (array_key_exists('photo', $b)) {
                $pdo->prepare('UPDATE players SET name=?,national_id=?,birth_year=?,position=?,jersey=?,category=?,insurance=?,insurance_expiry=?,photo=? WHERE id=?')
                    ->execute(array($name,$nationalId,$birthYear,$position,$jersey,$category,$insurance,$expiry,$photo,$id));
            } else {
                $pdo->prepare('UPDATE players SET name=?,national_id=?,birth_year=?,position=?,jersey=?,category=?,insurance=?,insurance_expiry=? WHERE id=?')
                    ->execute(array($name,$nationalId,$birthYear,$position,$jersey,$category,$insurance,$expiry,$id));
            }
        } else {
            $pdo->prepare('INSERT INTO players (name,national_id,birth_year,position,jersey,category,insurance,insurance_expiry,photo,club_id) VALUES (?,?,?,?,?,?,?,?,?,?)')
                ->execute(array($name,$nationalId,$birthYear,$position,$jersey,$category,$insurance,$expiry,$photo,$clubId));
        }
        json_out(array('ok' => true));
    }
    if ($action === 'player:delete') { $pdo->prepare('DELETE FROM players WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }
    if ($action === 'player:set-insurance') {
        $status = (isset($b['insurance']) && in_array($b['insurance'], array('VALID', 'EXPIRED', 'NONE'))) ? $b['insurance'] : 'NONE';
        $pdo->prepare('UPDATE players SET insurance=? WHERE id=?')->execute(array($status, $id));
        json_out(array('ok' => true));
    }

    /* ─── مسابقات ─── */
    if ($action === 'match:save') {
        $home = trim(isset($b['homeName']) ? (string)$b['homeName'] : '');
        $away = trim(isset($b['awayName']) ? (string)$b['awayName'] : '');
        if ($home === '' || $away === '') json_out(array('error' => 'نام دو تیم الزامی است.'), 400);
        if ($home === $away) json_out(array('error' => 'دو تیم نمی‌توانند یکسان باشند.'), 400);
        $validLeagues = array('U8_12','U12_15','U15_18','ADULT','FUTSAL1','FUTSAL2','F_PROV_JAVANAN','F_PROV_NOJAVANAN','F_PROV_NONAHALAN','F_CITY_OMID','F_CITY_NOJAVANAN','F_CITY_NONAHALAN','F_RAMDAN','F_EDARAT');
        $league = (isset($b['league']) && in_array($b['league'], $validLeagues)) ? $b['league'] : 'ADULT';
        $status = (isset($b['status']) && in_array($b['status'], array('SCHEDULED','LIVE','FINISHED','POSTPONED'))) ? $b['status'] : 'SCHEDULED';
        $dateTime = date('Y-m-d H:i:s', strtotime(isset($b['dateTime']) ? $b['dateTime'] : 'now'));
        $vals = array(
            $league, (int)(isset($b['week']) ? $b['week'] : 1), $home, $away,
            !empty($b['homeClubId']) ? (int)$b['homeClubId'] : null,
            !empty($b['awayClubId']) ? (int)$b['awayClubId'] : null,
            (isset($b['homeScore']) && $b['homeScore'] !== '' && $b['homeScore'] !== null) ? (int)$b['homeScore'] : null,
            (isset($b['awayScore']) && $b['awayScore'] !== '' && $b['awayScore'] !== null) ? (int)$b['awayScore'] : null,
            $status, $dateTime,
            (isset($b['venue']) && trim((string)$b['venue']) !== '') ? trim((string)$b['venue']) : null,
            !empty($b['refereeId']) ? (int)$b['refereeId'] : null,
        );
        if ($id) {
            $vals[] = $id;
            $pdo->prepare('UPDATE matches SET league=?,week=?,home_name=?,away_name=?,home_club_id=?,away_club_id=?,home_score=?,away_score=?,status=?,date_time=?,venue=?,referee_id=? WHERE id=?')->execute($vals);
        } else {
            $pdo->prepare('INSERT INTO matches (league,week,home_name,away_name,home_club_id,away_club_id,home_score,away_score,status,date_time,venue,referee_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')->execute($vals);
        }
        json_out(array('ok' => true));
    }
    if ($action === 'match:delete') { $pdo->prepare('DELETE FROM matches WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }

    if ($action === 'event:add') {
        if (trim(isset($b['playerName']) ? (string)$b['playerName'] : '') === '') json_out(array('error' => 'نام بازیکن الزامی است.'), 400);
        $type = (isset($b['type']) && in_array($b['type'], array('goal','penalty','owngoal','yellow','red'))) ? $b['type'] : 'goal';
        $pdo->prepare('INSERT INTO match_events (match_id,minute,type,player_name,side,note) VALUES (?,?,?,?,?,?)')
            ->execute(array(
                (int)$b['matchId'], (int)(isset($b['minute']) ? $b['minute'] : 1), $type,
                trim((string)$b['playerName']),
                (isset($b['side']) && $b['side'] === 'AWAY') ? 'AWAY' : 'HOME',
                (isset($b['note']) && trim((string)$b['note']) !== '') ? trim((string)$b['note']) : null,
            ));
        json_out(array('ok' => true));
    }
    if ($action === 'event:delete') { $pdo->prepare('DELETE FROM match_events WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }

    /* ─── داوران ─── */
    if ($action === 'referee:save') {
        if (trim(isset($b['name']) ? (string)$b['name'] : '') === '') json_out(array('error' => 'نام داور الزامی است.'), 400);
        $vals = array(
            trim((string)$b['name']),
            isset($b['grade']) ? (string)$b['grade'] : 'درجه دو',
            (isset($b['kind']) && $b['kind'] === 'فوتسال') ? 'فوتسال' : 'فوتبال',
            (isset($b['city']) && trim((string)$b['city']) !== '') ? trim((string)$b['city']) : null,
            (int)(isset($b['yearsActive']) ? $b['yearsActive'] : 0),
            (int)(isset($b['matchesCount']) ? $b['matchesCount'] : 0),
        );
        if ($id) {
            $vals[] = $id;
            $pdo->prepare('UPDATE referees SET name=?,grade=?,kind=?,city=?,years_active=?,matches_count=? WHERE id=?')->execute($vals);
        } else {
            $pdo->prepare('INSERT INTO referees (name,grade,kind,city,years_active,matches_count) VALUES (?,?,?,?,?,?)')->execute($vals);
        }
        json_out(array('ok' => true));
    }
    if ($action === 'referee:delete') { $pdo->prepare('DELETE FROM referees WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }
    if ($action === 'fsignup:delete') { $pdo->prepare('DELETE FROM futsal_signups WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }

    /* ─── اخبار ─── */
    if ($action === 'news:save') {
        if (trim(isset($b['title']) ? (string)$b['title'] : '') === '') json_out(array('error' => 'عنوان خبر الزامی است.'), 400);
        $title = trim((string)$b['title']);
        $category = isset($b['category']) ? (string)$b['category'] : 'اخبار هیئت';
        $excerpt = isset($b['excerpt']) ? (string)$b['excerpt'] : '';
        $body = isset($b['body']) ? (string)$b['body'] : '';
        $image = (isset($b['image']) && trim((string)$b['image']) !== '') ? trim((string)$b['image']) : null;
        $tags = array();
        if (isset($b['tags']) && trim((string)$b['tags']) !== '') {
            foreach (explode('،', (string)$b['tags']) as $t) if (trim($t) !== '') $tags[] = trim($t);
        }
        $featured = !empty($b['featured']) ? 1 : 0;
        if ($id) {
            $pdo->prepare('UPDATE news SET title=?,category=?,excerpt=?,body=?,image=?,tags=?,featured=? WHERE id=?')
                ->execute(array($title,$category,$excerpt,$body,$image,json_encode($tags, JSON_UNESCAPED_UNICODE),$featured,$id));
        } else {
            $pdo->prepare('INSERT INTO news (title,slug,category,excerpt,body,image,tags,featured) VALUES (?,?,?,?,?,?,?,?)')
                ->execute(array($title, slugify_admin($title) . '-' . substr((string)time(), -5), $category,$excerpt,$body,$image,json_encode($tags, JSON_UNESCAPED_UNICODE),$featured));
        }
        json_out(array('ok' => true));
    }
    if ($action === 'news:delete') { $pdo->prepare('DELETE FROM news WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }

    /* ─── دوره‌ها ─── */
    if ($action === 'course:save') {
        if (trim(isset($b['title']) ? (string)$b['title'] : '') === '') json_out(array('error' => 'عنوان دوره الزامی است.'), 400);
        $vals = array(
            trim((string)$b['title']),
            isset($b['kind']) ? (string)$b['kind'] : 'عمومی',
            (isset($b['instructor']) && trim((string)$b['instructor']) !== '') ? trim((string)$b['instructor']) : null,
            (isset($b['startDate']) && trim((string)$b['startDate']) !== '') ? trim((string)$b['startDate']) : null,
            (int)(isset($b['capacity']) ? $b['capacity'] : 30),
            (isset($b['location']) && trim((string)$b['location']) !== '') ? trim((string)$b['location']) : null,
            (isset($b['fee']) && trim((string)$b['fee']) !== '') ? trim((string)$b['fee']) : null,
            (isset($b['status']) && in_array($b['status'], array('open','closed','finished'))) ? $b['status'] : 'open',
            isset($b['description']) ? (string)$b['description'] : '',
        );
        if ($id) {
            $vals[] = $id;
            $pdo->prepare('UPDATE courses SET title=?,kind=?,instructor=?,start_date=?,capacity=?,location=?,fee=?,status=?,description=? WHERE id=?')->execute($vals);
        } else {
            $pdo->prepare('INSERT INTO courses (title,kind,instructor,start_date,capacity,location,fee,status,description) VALUES (?,?,?,?,?,?,?,?,?)')->execute($vals);
        }
        json_out(array('ok' => true));
    }
    if ($action === 'course:delete') { $pdo->prepare('DELETE FROM courses WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }
    /* ─── تأیید یا رد ثبت‌نام دوره‌ها ─── */
    if ($action === 'enroll:set') {
        $status = (isset($b['status']) && $b['status'] === 'REJECTED') ? 'REJECTED' : 'APPROVED';
        $valid = array('PENDING', 'APPROVED', 'REJECTED');
        $col = null;
        try {
            $r = $pdo->query("SHOW COLUMNS FROM course_enrollments LIKE 'status'");
            if ($r && $r->fetch()) $col = 'status';
        } catch (Exception $e) { $col = null; }
        if ($col === null) {
            try { $pdo->exec("ALTER TABLE course_enrollments ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'PENDING'"); $col = 'status'; }
            catch (Exception $e) { json_out(array('error' => 'ستون وضعیت در دیتابیس وجود ندارد.'), 400); }
        }
        $pdo->prepare('UPDATE course_enrollments SET status=? WHERE id=?')->execute(array($status, $id));
        json_out(array('ok' => true));
    }
    if ($action === 'enroll:delete') { $pdo->prepare('DELETE FROM course_enrollments WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }

    /* ─── گالری ─── */
    if ($action === 'gallery:save') {
        $title = trim(isset($b['title']) ? (string)$b['title'] : '');
        $url = trim(isset($b['url']) ? (string)$b['url'] : '');
        if ($title === '' || $url === '') json_out(array('error' => 'عنوان و آدرس تصویر الزامی است.'), 400);
        $category = (isset($b['category']) && trim((string)$b['category']) !== '') ? trim((string)$b['category']) : null;
        if ($id) {
            $pdo->prepare('UPDATE gallery_items SET title=?,url=?,category=? WHERE id=?')->execute(array($title,$url,$category,$id));
        } else {
            $pdo->prepare('INSERT INTO gallery_items (title,kind,url,category) VALUES (?, "IMAGE", ?, ?)')->execute(array($title,$url,$category));
        }
        json_out(array('ok' => true));
    }
    if ($action === 'gallery:delete') { $pdo->prepare('DELETE FROM gallery_items WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }

    /* ─── پیشکسوتان ─── */
    if ($action === 'veteran:save') {
        if (trim(isset($b['name']) ? (string)$b['name'] : '') === '') json_out(array('error' => 'نام پیشکسوت الزامی است.'), 400);
        $photo = (isset($b['photo']) && trim((string)$b['photo']) !== '') ? trim((string)$b['photo']) : null;
        $vals = array(
            trim((string)$b['name']),
            (isset($b['era']) && trim((string)$b['era']) !== '') ? trim((string)$b['era']) : null,
            (isset($b['role']) && trim((string)$b['role']) !== '') ? trim((string)$b['role']) : null,
            isset($b['bio']) ? (string)$b['bio'] : '',
            (isset($b['achievements']) && trim((string)$b['achievements']) !== '') ? trim((string)$b['achievements']) : null,
        );
        if ($id) {
            $pdo->prepare('UPDATE veterans SET name=?,era=?,role=?,bio=?,achievements=?,photo=? WHERE id=?')->execute(array_merge($vals, array($photo, $id)));
        } else {
            $pdo->prepare('INSERT INTO veterans (name,era,role,bio,achievements,photo) VALUES (?,?,?,?,?,?)')->execute(array_merge($vals, array($photo)));
        }
        json_out(array('ok' => true));
    }
    if ($action === 'veteran:delete') { $pdo->prepare('DELETE FROM veterans WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }

    /* ─── انضباطی ─── */
    if ($action === 'discipline:save') {
        $subject = trim(isset($b['subject']) ? (string)$b['subject'] : '');
        $verdict = trim(isset($b['verdict']) ? (string)$b['verdict'] : '');
        if ($subject === '' || $verdict === '') json_out(array('error' => 'موضوع و رأی الزامی است.'), 400);
        $vals = array(
            (isset($b['caseNo']) && trim((string)$b['caseNo']) !== '') ? trim((string)$b['caseNo']) : ('انضباطی-' . substr((string)time(), -6)),
            (isset($b['date']) && trim((string)$b['date']) !== '') ? trim((string)$b['date']) : date('Y/m/d'),
            (isset($b['clubName']) && trim((string)$b['clubName']) !== '') ? trim((string)$b['clubName']) : null,
            (isset($b['playerName']) && trim((string)$b['playerName']) !== '') ? trim((string)$b['playerName']) : null,
            $subject, $verdict,
            (isset($b['kind']) && trim((string)$b['kind']) !== '') ? trim((string)$b['kind']) : null,
        );
        if ($id) {
            $vals[] = $id;
            $pdo->prepare('UPDATE discipline_cases SET case_no=?,date=?,club_name=?,player_name=?,subject=?,verdict=?,kind=? WHERE id=?')->execute($vals);
        } else {
            $pdo->prepare('INSERT INTO discipline_cases (case_no,date,club_name,player_name,subject,verdict,kind) VALUES (?,?,?,?,?,?,?)')->execute($vals);
        }
        json_out(array('ok' => true));
    }
    if ($action === 'discipline:delete') { $pdo->prepare('DELETE FROM discipline_cases WHERE id=?')->execute(array($id)); json_out(array('ok' => true)); }

    /* ─── نقل و انتقالات ─── */
    if ($action === 'transfer:set') {
        $status = (isset($b['status']) && $b['status'] === 'APPROVED') ? 'APPROVED' : ((isset($b['status']) && $b['status'] === 'REJECTED') ? 'REJECTED' : 'PENDING');
        $pdo->prepare('UPDATE transfers SET status=? WHERE id=?')->execute(array($status, $id));
        json_out(array('ok' => true));
    }

    json_out(array('error' => 'عملیات نامعتبر'), 400);
} catch (Exception $e) {
    json_out(array('error' => 'خطای سرور: ' . (DEBUG_MODE ? $e->getMessage() : '')), 500);
}
