<?php
/* ═══ دریافت کل داده‌های پنل مدیر (GET + توکن مدیر) ═══ */
require dirname(__FILE__) . '/admin.php';
