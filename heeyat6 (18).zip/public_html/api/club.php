<?php
/* ═══ API پنل باشگاه ═══ سازگار با PHP 7.0 به بالا */
require_once dirname(__FILE__) . '/../db.php';
require_once dirname(__FILE__) . '/../auth.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $session = require_club();
    $pdo = db();
    $clubId = $session['clubId'];

    $st = $pdo->prepare('SELECT * FROM clubs WHERE id = ? LIMIT 1');
    $st->execute(array($clubId));
    $club = $st->fetch();
    if (!$club) json_out(array('error' => 'باشگاه یافت نشد.'), 404);
    $club['profile'] = $club['profile'] ? json_decode($club['profile'], true) : null;
    if (!is_array($club['profile'])) $club['profile'] = null;

    /* ─────────── GET ─────────── */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $players = array();
        $st = $pdo->prepare('SELECT * FROM players WHERE club_id = ?');
        $st->execute(array($clubId));
        foreach ($st->fetchAll() as $r) $players[] = row_map($r, array('id','club_id','birth_year','jersey'));

        $matches = array();
        $st = $pdo->prepare('SELECT * FROM matches WHERE home_club_id = ? OR away_club_id = ? ORDER BY date_time');
        $st->execute(array($clubId, $clubId));
        foreach ($st->fetchAll() as $r) $matches[] = row_map($r, array('id','week','home_club_id','away_club_id','home_score','away_score'));

        $transfers = array();
        $st = $pdo->prepare('SELECT * FROM transfers WHERE club_id = ? ORDER BY created_at DESC');
        $st->execute(array($clubId));
        foreach ($st->fetchAll() as $r) $transfers[] = row_map($r, array('id','club_id'));

        $st = $pdo->prepare('SELECT * FROM discipline_cases WHERE club_name = ? ORDER BY id DESC');
        $st->execute(array($club['name']));
        $discipline = $st->fetchAll();

        $clubNames = $pdo->query('SELECT name FROM clubs WHERE status = "APPROVED" ORDER BY name')->fetchAll(PDO::FETCH_COLUMN);

        json_out(array(
            'club' => $club,
            'players' => $players,
            'matches' => $matches,
            'transfers' => $transfers,
            'discipline' => $discipline,
            'clubNames' => $clubNames,
        ));
    }

    /* ─────────── POST ─────────── */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(array('error' => 'روش نامعتبر'), 405);
    $b = read_body();
    $action = isset($b['action']) ? $b['action'] : '';

    if ($action === 'profile') {
        $profile = array(
            'staff' => (isset($b['staff']) && is_array($b['staff'])) ? $b['staff'] : array(),
            'trainings' => (isset($b['trainings']) && is_array($b['trainings'])) ? $b['trainings'] : array(),
            'wizardDone' => true,
        );
        $pdo->prepare('UPDATE clubs SET address=?, license_no=?, description=?, founded_year=?, profile=? WHERE id=?')
            ->execute(array(
                isset($b['address']) ? (string)$b['address'] : (string)$club['address'],
                (isset($b['licenseNo']) && trim((string)$b['licenseNo']) !== '') ? trim((string)$b['licenseNo']) : null,
                (isset($b['description']) && trim((string)$b['description']) !== '') ? trim((string)$b['description']) : null,
                !empty($b['foundedYear']) ? (int)$b['foundedYear'] : $club['founded_year'],
                json_encode($profile, JSON_UNESCAPED_UNICODE),
                $clubId,
            ));
        json_out(array('ok' => true));
    }

    if ($action === 'player:add') {
        $name = trim(isset($b['name']) ? (string)$b['name'] : '');
        if ($name === '') json_out(array('error' => 'نام بازیکن الزامی است.'), 400);
        $pdo->prepare('INSERT INTO players (club_id,name,national_id,birth_year,position,jersey,category,insurance,photo) VALUES (?,?,?,?,?,?,?,"NONE",?)')
            ->execute(array(
                $clubId, $name,
                (isset($b['nationalId']) && trim((string)$b['nationalId']) !== '') ? trim((string)$b['nationalId']) : null,
                !empty($b['birthYear']) ? (int)$b['birthYear'] : null,
                (isset($b['position']) && trim((string)$b['position']) !== '') ? trim((string)$b['position']) : null,
                !empty($b['jersey']) ? (int)$b['jersey'] : null,
                (isset($b['category']) && $b['category'] === 'ACADEMY') ? 'ACADEMY' : 'FIRST',
                (isset($b['photo']) && trim((string)$b['photo']) !== '') ? trim((string)$b['photo']) : null,
            ));
        json_out(array('ok' => true));
    }

    if ($action === 'player:insurance') {
        $status = (isset($b['insurance']) && $b['insurance'] === 'VALID') ? 'VALID' : ((isset($b['insurance']) && $b['insurance'] === 'EXPIRED') ? 'EXPIRED' : 'NONE');
        $pdo->prepare('UPDATE players SET insurance=?, insurance_expiry=? WHERE id=?')
            ->execute(array($status, (isset($b['expiry']) && trim((string)$b['expiry']) !== '') ? trim((string)$b['expiry']) : null, (int)$b['id']));
        json_out(array('ok' => true));
    }

    if ($action === 'player:delete') {
        $pdo->prepare('DELETE FROM players WHERE id=?')->execute(array((int)$b['id']));
        json_out(array('ok' => true));
    }

    if ($action === 'transfer:request') {
        $player = trim(isset($b['playerName']) ? (string)$b['playerName'] : '');
        $to = trim(isset($b['toClub']) ? (string)$b['toClub'] : '');
        if ($player === '' || $to === '') json_out(array('error' => 'نام بازیکن و باشگاه مقصد الزامی است.'), 400);
        $pdo->prepare('INSERT INTO transfers (player_name,from_club,to_club,kind,status,club_id) VALUES (?,?,?,?,"PENDING",?)')
            ->execute(array(
                $player, $club['name'], $to,
                (isset($b['kind']) && $b['kind'] === 'RELEASE') ? 'RELEASE' : 'TRANSFER',
                $clubId,
            ));
        json_out(array('ok' => true));
    }

    json_out(array('error' => 'عملیات نامعتبر'), 400);
} catch (Exception $e) {
    json_out(array('error' => 'خطای سرور: ' . (DEBUG_MODE ? $e->getMessage() : '')), 500);
}
