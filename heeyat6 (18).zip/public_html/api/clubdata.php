<?php
/* ═══ دریافت اطلاعات پنل باشگاه (GET + توکن باشگاه) ═══ */
require dirname(__FILE__) . '/club.php';
