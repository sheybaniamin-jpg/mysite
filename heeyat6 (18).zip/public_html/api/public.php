<?php
/* ═══════════════════════════════════════════════════════════
   API عمومی — داده‌های سایت + ثبت‌نام‌ها
   خروجی مسابقات همیشه camelCase است (homeName, dateTime, ...)
   ═══════════════════════════════════════════════════════════ */
require_once dirname(__FILE__) . '/../db.php';

header('Content-Type: application/json; charset=utf-8');

/* ─────────────── توابع کمکی ─────────────── */

/* نام لیگ‌ها */
function leagues() {
    return array(
        'U8_12' => 'رده سنی ۸ تا ۱۲ سال', 'U12_15' => 'رده سنی ۱۲ تا ۱۵ سال',
        'U15_18' => 'رده سنی ۱۵ تا ۱۸ سال', 'ADULT' => 'رده بزرگسالان',
        'FUTSAL1' => 'لیگ دسته یک فوتسال کشور', 'FUTSAL2' => 'لیگ دسته دو فوتسال کشور',
        'F_PROV_JAVANAN' => 'لیگ فوتسال استان — جوانان', 'F_PROV_NOJAVANAN' => 'لیگ فوتسال استان — نوجوانان',
        'F_PROV_NONAHALAN' => 'لیگ فوتسال استان — نونهالان', 'F_CITY_OMID' => 'لیگ فوتسال شهرستان — امید',
        'F_CITY_NOJAVANAN' => 'لیگ فوتسال شهرستان — نوجوانان', 'F_CITY_NONAHALAN' => 'لیگ فوتسال شهرستان — نونهالان',
        'F_RAMDAN' => 'جام رمضان فوتسال', 'F_EDARAT' => 'لیگ فوتسال ادارات',
    );
}

/* نگاشت کلید لیگ فوتبال شهرستان به برچسب فارسی رده سنی */
function league_to_age_label($leagueKey) {
    $map = array('ADULT' => 'بزرگسالان', 'U15_18' => 'جوانان', 'U12_15' => 'نوجوانان', 'U8_12' => 'نونهالان');
    return isset($map[$leagueKey]) ? $map[$leagueKey] : null;
}

/* ساخت جدول رده‌بندی (برد ۳ / مساوی ۱ / باخت ۰).
   $teams: تیم‌هایی که حتی بدون مسابقه باید با امتیاز صفر در جدول باشند. */
function compute_standings($matches, $teams = array()) {
    $table = array();
    foreach ($teams as $t) {
        if (!isset($table[$t])) $table[$t] = array('team' => $t, 'played' => 0, 'wins' => 0, 'draws' => 0, 'losses' => 0, 'gf' => 0, 'ga' => 0, 'gd' => 0, 'points' => 0, 'form' => array());
    }
    $finished = array();
    foreach ($matches as $m) {
        if ($m['status'] === 'FINISHED' && $m['home_score'] !== null && $m['away_score'] !== null) $finished[] = $m;
    }
    usort($finished, 'cmp_date_asc');
    foreach ($finished as $m) {
        $hs = (int)$m['home_score']; $as = (int)$m['away_score'];
        $hn = $m['home_name']; $an = $m['away_name'];
        if (!isset($table[$hn])) $table[$hn] = array('team' => $hn, 'played' => 0, 'wins' => 0, 'draws' => 0, 'losses' => 0, 'gf' => 0, 'ga' => 0, 'gd' => 0, 'points' => 0, 'form' => array());
        if (!isset($table[$an])) $table[$an] = array('team' => $an, 'played' => 0, 'wins' => 0, 'draws' => 0, 'losses' => 0, 'gf' => 0, 'ga' => 0, 'gd' => 0, 'points' => 0, 'form' => array());
        $table[$hn]['played']++; $table[$an]['played']++;
        $table[$hn]['gf'] += $hs; $table[$hn]['ga'] += $as;
        $table[$an]['gf'] += $as; $table[$an]['ga'] += $hs;
        if ($hs > $as) {
            $table[$hn]['wins']++; $table[$hn]['points'] += 3; $table[$an]['losses']++;
            $table[$hn]['form'][] = 'W'; $table[$an]['form'][] = 'L';
        } elseif ($hs < $as) {
            $table[$an]['wins']++; $table[$an]['points'] += 3; $table[$hn]['losses']++;
            $table[$an]['form'][] = 'W'; $table[$hn]['form'][] = 'L';
        } else {
            $table[$hn]['draws']++; $table[$an]['draws']++;
            $table[$hn]['points']++; $table[$an]['points']++;
            $table[$hn]['form'][] = 'D'; $table[$an]['form'][] = 'D';
        }
    }
    $rows = array_values($table);
    foreach ($rows as $i => $r) {
        $rows[$i]['gd'] = $r['gf'] - $r['ga'];
        $rows[$i]['form'] = array_slice($r['form'], -5);
    }
    usort($rows, 'cmp_standings');
    return $rows;
}
function cmp_date_asc($a, $b) { return strtotime($a['date_time']) - strtotime($b['date_time']); }
function cmp_standings($a, $b) {
    if ($b['points'] !== $a['points']) return $b['points'] - $a['points'];
    if ($b['gd'] !== $a['gd']) return $b['gd'] - $a['gd'];
    if ($b['gf'] !== $a['gf']) return $b['gf'] - $a['gf'];
    return strcmp((string)$a['team'], (string)$b['team']);
}

/* خواندن مسابقات (خروجی دیتابیس = snake_case) */
function fetch_matches($league = null) {
    $sql = 'SELECT m.*, r.name AS referee_name FROM matches m LEFT JOIN referees r ON r.id = m.referee_id';
    $params = array();
    if ($league) { $sql .= ' WHERE m.league = ?'; $params[] = $league; }
    $sql .= ' ORDER BY m.date_time DESC';
    try {
        $st = db()->prepare($sql);
        $st->execute($params);
        return $st->fetchAll();
    } catch (Exception $e) {
        return array();
    }
}

/* تبدیل مسابقه به فرمت فرانت‌اند (camelCase) */
function match_to_camel($r) {
    return array(
        'id' => (int)$r['id'],
        'league' => $r['league'],
        'week' => $r['week'] !== null ? (int)$r['week'] : null,
        'homeName' => $r['home_name'],
        'awayName' => $r['away_name'],
        'homeClubId' => $r['home_club_id'] !== null ? (int)$r['home_club_id'] : null,
        'awayClubId' => $r['away_club_id'] !== null ? (int)$r['away_club_id'] : null,
        'homeScore' => $r['home_score'] !== null ? (int)$r['home_score'] : null,
        'awayScore' => $r['away_score'] !== null ? (int)$r['away_score'] : null,
        'status' => $r['status'],
        'dateTime' => $r['date_time'],
        'venue' => $r['venue'],
        'refereeId' => isset($r['referee_id']) && $r['referee_id'] !== null ? (int)$r['referee_id'] : null,
        'refereeName' => isset($r['referee_name']) ? $r['referee_name'] : null,
    );
}
function matches_to_camel($rows) {
    $out = array();
    foreach ($rows as $r) $out[] = match_to_camel($r);
    return $out;
}

/* تبدیل رویدادها به فرمت فرانت‌اند */
function events_to_camel($rows) {
    $out = array();
    foreach ($rows as $r) {
        $out[] = array(
            'id' => (int)$r['id'],
            'minute' => (int)$r['minute'],
            'type' => $r['type'],
            'playerName' => $r['player_name'],
            'side' => $r['side'],
            'note' => isset($r['note']) ? $r['note'] : null,
        );
    }
    return $out;
}

/* تیم‌های تأییدشده‌ی یک رده سنی برای نمایش در جدول با امتیاز صفر.
   رده سنی باشگاه می‌تواند چندگانه (با کاما) باشد؛ اگر خالی باشد یعنی همه رده‌ها. */
function fetch_age_teams($leagueKey) {
    $label = league_to_age_label($leagueKey);
    if ($label === null) return array();
    try {
        $rows = db()->query('SELECT name, age_group FROM clubs WHERE status = "APPROVED"')->fetchAll();
    } catch (Exception $e) {
        return array();
    }
    $out = array();
    foreach ($rows as $c) {
        $ag = trim((string)(isset($c['age_group']) ? $c['age_group'] : ''));
        if ($ag === '') { $out[] = $c['name']; continue; }
        $parts = array_map('trim', explode(',', $ag));
        if (in_array($label, $parts)) $out[] = $c['name'];
    }
    return $out;
}

function filter_matches($matches, $league) {
    $out = array();
    foreach ($matches as $m) if ($m['league'] === $league) $out[] = $m;
    return $out;
}

function fetch_all_news() {
    try {
        $rows = db()->query('SELECT * FROM news ORDER BY published_at DESC, id DESC')->fetchAll();
    } catch (Exception $e) {
        return array();
    }
    $out = array();
    foreach ($rows as $n) {
        $n['id'] = (int)$n['id'];
        $n['views'] = (int)$n['views'];
        $n['featured'] = (bool)$n['featured'];
        $tags = $n['tags'] ? json_decode($n['tags'], true) : array();
        $n['tags'] = is_array($tags) ? $tags : array();
        $out[] = $n;
    }
    return $out;
}

function slugify($s) {
    $s = mb_strtolower(trim($s));
    $s = preg_replace('/[^\p{L}\p{N}]+/u', '-', $s);
    $s = trim($s, '-');
    return $s !== '' ? mb_substr($s, 0, 80) : 'item-' . time();
}

/* ─────────────── GET ─────────────── */
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $section = isset($_GET['section']) ? $_GET['section'] : 'home';

        if ($section === 'home') {
            $news = fetch_all_news();
            $featured = array();
            foreach ($news as $n) if ($n['featured']) $featured[] = $n;
            $matches = fetch_matches();
            $clubs = array(); $refs = array(); $coursesAll = array(); $gallery = array(); $vets = array(); $disc = array(); $playersCount = 0;
            try { $clubs = db()->query('SELECT id,name,status,activity_type,logo FROM clubs ORDER BY name')->fetchAll(); } catch (Exception $e) {}
            try { $refs = db()->query('SELECT * FROM referees ORDER BY matches_count DESC LIMIT 4')->fetchAll(); } catch (Exception $e) {}
            try { $coursesAll = db()->query('SELECT * FROM courses ORDER BY start_date')->fetchAll(); } catch (Exception $e) {}
            try { $gallery = db()->query('SELECT * FROM gallery_items ORDER BY created_at DESC LIMIT 6')->fetchAll(); } catch (Exception $e) {}
            try { $vets = db()->query('SELECT * FROM veterans')->fetchAll(); } catch (Exception $e) {}
            try { $disc = db()->query('SELECT * FROM discipline_cases ORDER BY id DESC LIMIT 3')->fetchAll(); } catch (Exception $e) {}
            try { $playersCount = (int)db()->query('SELECT COUNT(*) FROM players')->fetchColumn(); } catch (Exception $e) {}
            $courses = array();
            foreach ($coursesAll as $c) if ($c['status'] === 'open') $courses[] = $c;
            json_out(array(
                'featuredNews' => array_slice($featured, 0, 4),
                'latestNews' => array_slice($news, 0, 6),
                'matches' => matches_to_camel($matches),
                'clubs' => $clubs,
                'referees' => $refs,
                'courses' => $courses,
                'gallery' => $gallery,
                'veterans' => $vets,
                'discipline' => $disc,
                'playersCount' => $playersCount,
                'adultStandings' => compute_standings(filter_matches($matches, 'ADULT'), fetch_age_teams('ADULT')),
            ));
        }

        if ($section === 'news') json_out(array('news' => fetch_all_news()));

        if ($section === 'news-item') {
            $slug = isset($_GET['slug']) ? $_GET['slug'] : '';
            $st = db()->prepare('SELECT * FROM news WHERE slug = ? LIMIT 1');
            $st->execute(array($slug));
            $article = $st->fetch();
            if (!$article) json_out(array('error' => 'خبر یافت نشد.'), 404);
            try { db()->prepare('UPDATE news SET views = views + 1 WHERE id = ?')->execute(array($article['id'])); } catch (Exception $e) {}
            $all = fetch_all_news();
            $related = array();
            foreach ($all as $n) if ($n['id'] != $article['id']) $related[] = $n;
            json_out(array('article' => $article, 'related' => array_slice($related, 0, 3)));
        }

        if ($section === 'matches') json_out(array('matches' => matches_to_camel(fetch_matches())));

        if ($section === 'match') {
            $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
            $st = db()->prepare('SELECT m.*, r.name AS referee_name FROM matches m LEFT JOIN referees r ON r.id = m.referee_id WHERE m.id = ? LIMIT 1');
            $st->execute(array($id));
            $m = $st->fetch();
            if (!$m) json_out(array('error' => 'مسابقه یافت نشد.'), 404);
            $ev = array();
            try {
                $evst = db()->prepare('SELECT * FROM match_events WHERE match_id = ? ORDER BY minute');
                $evst->execute(array($id));
                $ev = $evst->fetchAll();
            } catch (Exception $e) {}
            json_out(array(
                'match' => match_to_camel($m),
                'events' => events_to_camel($ev),
                'refereeName' => isset($m['referee_name']) ? $m['referee_name'] : null,
            ));
        }

        if ($section === 'standings') {
            $all = fetch_matches();
            $tables = array();
            foreach (array_keys(leagues()) as $key) {
                $teams = in_array($key, array('ADULT', 'U15_18', 'U12_15', 'U8_12')) ? fetch_age_teams($key) : array();
                $tables[$key] = compute_standings(filter_matches($all, $key), $teams);
            }
            json_out(array('tables' => $tables));
        }

        if ($section === 'futsal') {
            $all = fetch_matches();
            $keys = array('FUTSAL1', 'FUTSAL2', 'F_PROV_JAVANAN', 'F_PROV_NOJAVANAN', 'F_PROV_NONAHALAN', 'F_CITY_OMID', 'F_CITY_NOJAVANAN', 'F_CITY_NONAHALAN', 'F_RAMDAN', 'F_EDARAT');
            $out = array();
            foreach ($keys as $k) {
                $list = filter_matches($all, $k);
                $fin = array(); $up = array();
                foreach ($list as $m) { if ($m['status'] === 'SCHEDULED') $up[] = $m; else $fin[] = $m; }
                usort($up, 'cmp_date_asc');
                $out[$k] = array(
                    'standings' => compute_standings($list),
                    'finished' => matches_to_camel(array_slice($fin, 0, 6)),
                    'upcoming' => matches_to_camel(array_slice($up, 0, 6)),
                );
            }
            json_out(array('leagues' => $out));
        }

        if ($section === 'referees') { try { json_out(array('referees' => db()->query('SELECT * FROM referees ORDER BY name')->fetchAll())); } catch (Exception $e) { json_out(array('referees' => array())); } }
        if ($section === 'courses') { try { json_out(array('courses' => db()->query('SELECT * FROM courses ORDER BY start_date')->fetchAll())); } catch (Exception $e) { json_out(array('courses' => array())); } }
        if ($section === 'gallery') { try { json_out(array('gallery' => db()->query('SELECT * FROM gallery_items ORDER BY created_at DESC')->fetchAll())); } catch (Exception $e) { json_out(array('gallery' => array())); } }
        if ($section === 'veterans') { try { json_out(array('veterans' => db()->query('SELECT * FROM veterans')->fetchAll())); } catch (Exception $e) { json_out(array('veterans' => array())); } }
        if ($section === 'discipline') { try { json_out(array('discipline' => db()->query('SELECT * FROM discipline_cases ORDER BY id DESC')->fetchAll())); } catch (Exception $e) { json_out(array('discipline' => array())); } }

        json_out(array('error' => 'بخش نامعتبر'), 400);
    }

    /* ─────────────── POST ─────────────── */
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $b = read_body();
        $action = isset($b['action']) ? $b['action'] : '';

        if ($action === 'club-application') {
            /* همه فیلدهای ستاره‌دار الزامی هستند: پروانه ماده ۵، مدیر عامل، لوگو و مدارک */
            $required = array('name', 'ownerName', 'ownerNationalId', 'ownerPhone', 'activityType', 'address', 'licenseNo', 'ceoName', 'logoUrl', 'docsUrl');
            foreach ($required as $f) {
                if (!isset($b[$f]) || trim((string)$b[$f]) === '') {
                    json_out(array('error' => 'لطفاً کلیه فیلدهای الزامی را تکمیل کنید (پروانه ماده ۵، مدیر عامل، لوگو و بارگذاری مدارک).'), 400);
                }
            }
            $ageGroup = trim(isset($b['ageGroup']) ? (string)$b['ageGroup'] : '');
            if ($ageGroup === '') json_out(array('error' => 'حداقل یک رده سنی را انتخاب کنید.'), 400);

            $name = trim((string)$b['name']);
            $st = db()->prepare('SELECT id FROM clubs WHERE name = ? LIMIT 1');
            $st->execute(array($name));
            if ($st->fetch()) json_out(array('error' => 'باشگاهی با این نام قبلاً ثبت شده است.'), 409);

            $desc = trim(isset($b['description']) ? (string)$b['description'] : '');
            $docsUrl = trim((string)$b['docsUrl']);
            if ($docsUrl !== '') $desc = trim($desc . ' | مدارک: ' . $docsUrl, ' |');

            /* اطلاعات مدیریتی باشگاه: مالک + مدیر عامل */
            $mgmt = json_encode(array(
                'owner' => trim((string)$b['ownerName']),
                'ceo' => trim((string)$b['ceoName']),
            ), JSON_UNESCAPED_UNICODE);

            $logoUrl = trim((string)$b['logoUrl']);

            $baseFull = array(
                $name,
                trim((string)$b['ownerName']),
                trim((string)$b['ownerNationalId']),
                trim((string)$b['ownerPhone']),
                (string)$b['activityType'],
                trim((string)$b['licenseNo']),
                trim((string)$b['address']),
                $desc !== '' ? $desc : null,
                $mgmt,
                $logoUrl,
                $ageGroup,
            );
            try {
                db()->prepare('INSERT INTO clubs (name, owner_name, owner_national_id, owner_phone, activity_type, license_no, address, description, profile, logo, age_group, status) VALUES (?,?,?,?,?,?,?,?,?,?,?, "PENDING_APPROVAL")')
                    ->execute($baseFull);
            } catch (Exception $e) {
                /* اگر ستون‌های تازه در دیتابیس نبود، بدون آن‌ها ثبت کن */
                db()->prepare('INSERT INTO clubs (name, owner_name, owner_national_id, owner_phone, activity_type, license_no, address, description, status) VALUES (?,?,?,?,?,?,?,?, "PENDING_APPROVAL")')
                    ->execute(array($baseFull[0], $baseFull[1], $baseFull[2], $baseFull[3], $baseFull[4], $baseFull[5], $baseFull[6], $baseFull[7]));
            }
            json_out(array('ok' => true, 'status' => 'PENDING_APPROVAL'));
        }

        if ($action === 'talent') {
            if (empty($b['name']) || empty($b['phone']) || empty($b['birthYear'])) json_out(array('error' => 'نام، سال تولد و شماره تماس الزامی است.'), 400);
            db()->prepare('INSERT INTO talent_regs (name, birth_year, phone, city, position, note) VALUES (?,?,?,?,?,?)')
                ->execute(array(
                    trim((string)$b['name']), (int)$b['birthYear'], trim((string)$b['phone']),
                    (isset($b['city']) && trim((string)$b['city']) !== '') ? trim((string)$b['city']) : null,
                    (isset($b['position']) && trim((string)$b['position']) !== '') ? trim((string)$b['position']) : null,
                    (isset($b['note']) && trim((string)$b['note']) !== '') ? trim((string)$b['note']) : null,
                ));
            json_out(array('ok' => true));
        }

        if ($action === 'enroll') {
            if (empty($b['name']) || empty($b['phone']) || empty($b['courseId'])) json_out(array('error' => 'نام و شماره تماس الزامی است.'), 400);
            $st = db()->prepare('SELECT * FROM courses WHERE id = ? LIMIT 1');
            $st->execute(array((int)$b['courseId']));
            $c = $st->fetch();
            if (!$c || $c['status'] !== 'open') json_out(array('error' => 'ثبت‌نام این دوره فعال نیست.'), 400);
            if ((int)$c['enrolled'] >= (int)$c['capacity']) json_out(array('error' => 'ظرفیت دوره تکمیل شده است.'), 400);
            db()->prepare('INSERT INTO course_enrollments (course_id, name, phone, national_id) VALUES (?,?,?,?)')
                ->execute(array((int)$c['id'], trim((string)$b['name']), trim((string)$b['phone']), (isset($b['nationalId']) && trim((string)$b['nationalId']) !== '') ? trim((string)$b['nationalId']) : null));
            db()->prepare('UPDATE courses SET enrolled = enrolled + 1 WHERE id = ?')->execute(array((int)$c['id']));
            json_out(array('ok' => true));
        }

        if ($action === 'futsal-signup') {
            if (empty($b['teamName']) || empty($b['phone'])) json_out(array('error' => 'نام تیم و شماره تماس الزامی است.'), 400);
            db()->prepare('INSERT INTO futsal_signups (league, team_name, contact_name, phone, note) VALUES (?,?,?,?,?)')
                ->execute(array(
                    isset($b['league']) ? (string)$b['league'] : 'F_EDARAT',
                    trim((string)$b['teamName']),
                    (isset($b['contactName']) && trim((string)$b['contactName']) !== '') ? trim((string)$b['contactName']) : null,
                    trim((string)$b['phone']),
                    (isset($b['note']) && trim((string)$b['note']) !== '') ? trim((string)$b['note']) : null,
                ));
            json_out(array('ok' => true));
        }

        json_out(array('error' => 'عملیات نامعتبر'), 400);
    }

    json_out(array('error' => 'روش نامعتبر'), 405);
} catch (Exception $e) {
    json_out(array('error' => 'خطای سرور: ' . (DEBUG_MODE ? $e->getMessage() : '')), 500);
}
