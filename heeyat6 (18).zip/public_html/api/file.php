<?php
/* ═══ نمایش فایل‌های آپلودشده ═══
   آدرس: api/file.php?name=نام-فایل */
require_once dirname(__FILE__) . '/../config.php';

$name = isset($_GET['name']) ? $_GET['name'] : '';
if (!preg_match('/^[\w\x{0600}-\x{06FF}.-]+$/u', $name) || strpos($name, '..') !== false) {
    http_response_code(400);
    exit('نام فایل نامعتبر است.');
}

$types = array('.jpg' => 'image/jpeg', '.jpeg' => 'image/jpeg', '.png' => 'image/png', '.webp' => 'image/webp', '.gif' => 'image/gif');
$file = UPLOAD_DIR . '/' . $name;

if (!is_file($file)) {
    http_response_code(404);
    exit('فایل یافت نشد.');
}

$dot = strrpos($name, '.');
$ext = $dot !== false ? strtolower(substr($name, $dot)) : '';
header('Content-Type: ' . (isset($types[$ext]) ? $types[$ext] : 'application/octet-stream'));
header('Cache-Control: public, max-age=86400');
header('Content-Length: ' . filesize($file));
readfile($file);
exit;
