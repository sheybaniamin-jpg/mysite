<?php
/* ═══ API احراز هویت: ورود مدیر / باشگاه / خروج / نشست ═══ */
require_once dirname(__FILE__) . '/../db.php';
require_once dirname(__FILE__) . '/../auth.php';

header('Content-Type: application/json; charset=utf-8');

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $s = get_session();
        if (!$s) json_out(array('error' => 'وارد نشده‌اید.'), 401);
        json_out(array('ok' => true, 'role' => $s['role'], 'name' => $s['role'] === 'club' ? $s['name'] : null));
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(array('error' => 'روش نامعتبر'), 405);
    $b = read_body();
    $action = isset($b['action']) ? $b['action'] : '';

    if ($action === 'admin-login') {
        $key = isset($b['key']) ? (string)$b['key'] : '';
        if (verify_admin_key($key)) {
            $token = make_token(array('role' => 'admin'));
            set_session_cookie($token);
            json_out(array('ok' => true, 'token' => $token));
        }
        json_out(array('error' => 'کلید محرمانه نامعتبر است.'), 401);
    }

    if ($action === 'club-login') {
        $username = trim(isset($b['username']) ? (string)$b['username'] : '');
        $password = isset($b['password']) ? (string)$b['password'] : '';
        if ($username === '' || $password === '') json_out(array('error' => 'نام کاربری و رمز عبور را وارد کنید.'), 400);

        $st = db()->prepare('SELECT * FROM clubs WHERE username = ? LIMIT 1');
        $st->execute(array($username));
        $club = $st->fetch();
        if (!$club || $club['password'] !== $password) json_out(array('error' => 'نام کاربری یا رمز عبور اشتباه است.'), 401);
        if ($club['status'] !== 'APPROVED') json_out(array('error' => 'حساب باشگاه هنوز توسط هیئت تأیید نشده است.'), 403);

        $token = make_token(array('role' => 'club', 'clubId' => (int)$club['id'], 'name' => $club['name']));
        set_session_cookie($token);
        json_out(array('ok' => true, 'token' => $token));
    }

    if ($action === 'logout') {
        clear_session_cookie();
        json_out(array('ok' => true));
    }

    json_out(array('error' => 'عملیات نامعتبر'), 400);
} catch (Exception $e) {
    json_out(array('error' => 'خطای سرور: ' . (DEBUG_MODE ? $e->getMessage() : '')), 500);
}
