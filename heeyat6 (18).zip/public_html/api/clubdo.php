<?php
/* ═══ عملیات‌های پنل باشگاه (POST + توکن باشگاه) ═══ */
require dirname(__FILE__) . '/club.php';
