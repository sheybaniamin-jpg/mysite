<?php
/* ═══ آپلود عکس (مثل عکس بازیکن) ═══ سازگار با PHP 7.0 */
require_once dirname(__FILE__) . '/../db.php';
require_once dirname(__FILE__) . '/../auth.php';

header('Content-Type: application/json; charset=utf-8');

try {
    if (!get_session()) json_out(array('error' => 'ابتدا وارد شوید.'), 401);
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(array('error' => 'روش نامعتبر'), 405);

    $b = read_body();
    $dataUrl = isset($b['dataUrl']) ? (string)$b['dataUrl'] : '';
    $fileName = isset($b['fileName']) ? (string)$b['fileName'] : 'image';

    if (!preg_match('#^data:(image/[a-zA-Z0-9.+-]+);base64,(.+)$#s', $dataUrl, $m)) {
        json_out(array('error' => 'فقط فایل تصویری مجاز است.'), 400);
    }
    if (strlen($m[2]) > 6 * 1024 * 1024) {
        json_out(array('error' => 'حجم عکس نباید بیشتر از ۴ مگابایت باشد.'), 400);
    }

    $extMap = array('image/jpeg' => '.jpg', 'image/jpg' => '.jpg', 'image/png' => '.png', 'image/webp' => '.webp', 'image/gif' => '.gif');
    $ext = isset($extMap[strtolower($m[1])]) ? $extMap[strtolower($m[1])] : '.jpg';
    $base = preg_replace('/\.[a-z0-9]+$/i', '', $fileName);
    $base = preg_replace('/[^\w\x{0600}-\x{06FF}-]+/u', '-', $base);
    if (function_exists('mb_substr')) $base = mb_substr($base, 0, 40);
    if ($base === '') $base = 'image';
    $name = time() . '-' . $base . $ext;

    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
    $bytes = base64_decode($m[2], true);
    if ($bytes === false) json_out(array('error' => 'محتوای عکس نامعتبر است.'), 400);
    file_put_contents(UPLOAD_DIR . '/' . $name, $bytes);

    json_out(array('ok' => true, 'url' => 'api/file.php?name=' . rawurlencode($name)));
} catch (Exception $e) {
    json_out(array('error' => 'خطا در ذخیره عکس: ' . (DEBUG_MODE ? $e->getMessage() : '')), 500);
}
