<?php
/* ═══ سیستم ورود ═══
   ورود مدیر: با رمز حساب مدیر (PANEL_PASSWORD)
   ورود باشگاه: با نام کاربری و رمز عبوری که پنل مدیر برای آن باشگاه صادر کرده است
   GET  ?clubs=1 → لیست باشگاه‌های فعال
   GET           → اطلاعات نشست فعلی
   POST {mode: admin, password}  یا  {mode: club, username, password} */
require_once dirname(__FILE__) . '/../db.php';
require_once dirname(__FILE__) . '/../auth.php';

header('Content-Type: application/json; charset=utf-8');

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['clubs'])) {
            $rows = db()->query('SELECT id, name FROM clubs WHERE status = "APPROVED" ORDER BY name')->fetchAll();
            json_out(array('ok' => true, 'clubs' => $rows));
        }
        $s = get_session();
        if (!$s) json_out(array('error' => 'وارد نشده‌اید.'), 401);
        json_out(array('ok' => true, 'role' => $s['role'], 'name' => isset($s['name']) ? $s['name'] : null));
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(array('error' => 'روش نامعتبر'), 405);
    $b = read_body();
    $mode = isset($b['mode']) ? $b['mode'] : 'admin';
    $pass = isset($b['password']) ? (string)$b['password'] : '';

    /* ─────────── ورود باشگاه: با نام کاربری + رمز صادرشده توسط پنل مدیر ─────────── */
    if ($mode === 'club') {
        $username = trim(isset($b['username']) ? (string)$b['username'] : '');
        if ($username === '' || $pass === '') json_out(array('error' => 'نام کاربری و رمز عبور باشگاه را وارد کنید.'), 400);
        $st = db()->prepare('SELECT * FROM clubs WHERE username = ? LIMIT 1');
        $st->execute(array($username));
        $club = $st->fetch();
        /* برای جلوگیری از افشای وجود حساب، پیام یکسان می‌دهیم */
        if (!$club || !hash_equals((string)$club['password'], $pass)) {
            json_out(array('error' => 'نام کاربری یا رمز عبور باشگاه اشتباه است.'), 401);
        }
        if ($club['status'] !== 'APPROVED') json_out(array('error' => 'حساب این باشگاه هنوز توسط هیئت تأیید نشده است.'), 403);
        $token = make_token(array('role' => 'club', 'clubId' => (int)$club['id'], 'name' => $club['name']));
        set_session_cookie($token);
        json_out(array('ok' => true, 'token' => $token, 'club' => $club['name']));
    }

    /* ─────────── ورود مدیر: فقط با رمز حساب مدیر ─────────── */
    if (!hash_equals(PANEL_PASSWORD, $pass)) {
        json_out(array('error' => 'رمز عبور مدیر اشتباه است.'), 401);
    }
    $token = make_token(array('role' => 'admin'));
    set_session_cookie($token);
    json_out(array('ok' => true, 'token' => $token));
} catch (Exception $e) {
    json_out(array('error' => 'خطای سرور: ' . (DEBUG_MODE ? $e->getMessage() : '')), 500);
}
