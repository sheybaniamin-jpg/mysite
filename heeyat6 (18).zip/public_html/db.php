<?php
/* ═══════════════════════════════════════════════════════════
   اتصال امن به دیتابیس با PDO + توابع کمکی
   سازگار با PHP 7.0 به بالا
   ═══════════════════════════════════════════════════════════ */
require_once dirname(__FILE__) . '/config.php';

/* بافر کردن خروجی تا هیچ متن اضافه‌ای قبل از JSON چاپ نشود */
if (!ob_get_level()) { ob_start(); }

function db() {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            )
        );
        $pdo->exec("SET NAMES utf8mb4");
    }
    return $pdo;
}

/* خروجی JSON با هدرهای مناسب — بافرها خالی می‌شوند تا JSON همیشه تمیز باشد */
function json_out($data, $code = 200) {
    while (ob_get_level() > 0) { ob_end_clean(); }
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/* خواندن بدنه JSON درخواست */
function read_body() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : array();
}

/* تبدیل ردیف دیتابیس: ستون‌های عددی و بولی */
function row_map($row, $ints = array(), $bools = array()) {
    foreach ($ints as $k) {
        $row[$k] = (isset($row[$k]) && $row[$k] !== null) ? (int)$row[$k] : null;
    }
    foreach ($bools as $k) {
        $row[$k] = isset($row[$k]) ? (bool)$row[$k] : false;
    }
    return $row;
}
