/* ═══════════════════════════════════════════════════════════
   کتابخانه مشترک سامانه هیئت فوتبال شهرستان بیرجند
   (جاوااسکریپت خالص — بدون فریم‌ورک)

   📷 تصاویر سایت:
   - همه عکس‌ها را در پوشه  public/images  قرار دهید.
   - لوگوی باشگاه‌ها:  public/images/logos/نام-باشگاه.png
     سپس مسیر را در همین فایل، بخش «لوگوی باشگاه‌ها» وارد کنید.
   - تصویر اخبار/گالری هم از پنل مدیریت (آدرس فایل) ثبت می‌شود.
   ═══════════════════════════════════════════════════════════ */

/* ─── لود Tailwind CSS از CDN (بدون ریست استایل‌های سایت) ─── */
(function () {
  var s = document.createElement("script");
  s.src = "https://cdn.tailwindcss.com";
  s.onload = function () {
    if (window.tailwind) window.tailwind.config = { corePlugins: { preflight: false } };
  };
  document.head.appendChild(s);
})();

/* ─── لیگ‌ها و رده‌ها ─── */
const LEAGUES = {
  // فوتبال شهرستان
  U8_12:            { label: "رده سنی ۸ تا ۱۲ سال", short: "۸ تا ۱۲ سال" },
  U12_15:           { label: "رده سنی ۱۲ تا ۱۵ سال", short: "۱۲ تا ۱۵ سال" },
  U15_18:           { label: "رده سنی ۱۵ تا ۱۸ سال", short: "۱۵ تا ۱۸ سال" },
  ADULT:            { label: "رده بزرگسالان", short: "بزرگسالان" },
  // فوتسال کشوری
  FUTSAL1:          { label: "لیگ دسته یک فوتسال کشور", short: "لیگ یک کشور" },
  FUTSAL2:          { label: "لیگ دسته دو فوتسال کشور", short: "لیگ دو کشور" },
  // لیگ‌های فوتسال استان
  F_PROV_JAVANAN:   { label: "لیگ فوتسال استان — جوانان", short: "استان · جوانان" },
  F_PROV_NOJAVANAN: { label: "لیگ فوتسال استان — نوجوانان", short: "استان · نوجوانان" },
  F_PROV_NONAHALAN: { label: "لیگ فوتسال استان — نونهالان", short: "استان · نونهالان" },
  // لیگ فوتسال شهرستان
  F_CITY_OMID:      { label: "لیگ فوتسال شهرستان — امید", short: "شهرستان · امید" },
  F_CITY_NOJAVANAN: { label: "لیگ فوتسال شهرستان — نوجوانان", short: "شهرستان · نوجوانان" },
  F_CITY_NONAHALAN: { label: "لیگ فوتسال شهرستان — نونهالان", short: "شهرستان · نونهالان" },
  // لیگ‌های آزاد فوتسال
  F_RAMDAN:         { label: "جام رمضان فوتسال", short: "جام رمضان" },
  F_EDARAT:         { label: "لیگ فوتسال ادارات", short: "لیگ ادارات" },
};

/* ═══════════════════════════════════════════════════════════
   📷 تنظیمات عکس‌ها و لوگوها
   هر جا نوشته «آدرس عکس» یعنی آنجا محل گذاشتن مسیر تصویر است:
   فایل عکس را در پوشه  public/images  بگذارید و به‌جای کلمهٔ
   «آدرس عکس»، مسیر آن را بنویسید؛ مثلاً:  images/logos/jazireh.png
   ═══════════════════════════════════════════════════════════ */

/* ─── 📷 لوگوی هیئت فوتبال (گوشه سایت، فوتر و صفحات ورود) ─── */
const LOGO_HEIAT = "images/heeyatlogo.jpg";

/* ─── 📷 لوگوی باشگاه‌ها ──────────────────────────────────────
   فایل هر لوگو در پوشه  public/images  قرار دارد. */
const TEAM_LOGOS = {
  "زرین": "images/zarin.png",
  "جزیره": "images/jazire.jpg",
  "نود": "images/navad.jpg",
  "ایریا شوکت": "images/ayriashokat.jpg",
  "مهرعظام": "images/mehrezam.jpg",
  "بهراد": "images/behrad.webp",
  "ایران مهر": "images/iranmehr.jpg",
  "نوین": "images/novin.jpg",
  "جاویدان": "images/javidan.jpg",
  "ملک": "images/malek.jpg",
  "سرخ پوشان": "images/sorkposhan.jpg",
  "ستارگان ایران": "images/iranstar.png",
  "ستارگان کویر": "images/setaregankavir.jpg",
  "جوان پارس": "images/javanpars.jpg",
  "ایران جوان": "images/iranjavan.jpg",
  "پیشگامان": "images/pishgaman.jpg",
  "پدیده": "images/bahman.jpg",
};

/* آیا مقدار هنوز «آدرس عکس» (پر نشده) است؟ */
function isPlaceholder(u) {
  return !u || String(u).trim() === "آدرس عکس";
}

/* لوگوی هیئت: اگر مسیر ثبت شد عکس، وگرنه کادرِ جای لوگو */
function logoHtml(size) {
  size = size || 52;
  if (!isPlaceholder(LOGO_HEIAT)) {
    return `<img src="${esc(LOGO_HEIAT)}" alt="لوگوی هیئت فوتبال بیرجند" style="width:${size}px;height:${size}px;object-fit:contain;border-radius:8px" />`;
  }
  return `<span class="logo-ph" style="width:${size}px;height:${size}px"><span>لوگوی هیئت</span><small>آدرس عکس</small></span>`;
}

/* ─── قالب‌بندی فارسی ─── */
function faNum(v) {
  if (v === null || v === undefined) return "—";
  return String(v).replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);
}
function faDate(d, opts) {
  if (!d) return "—";
  try {
    return new Intl.DateTimeFormat("fa-IR", opts || { year: "numeric", month: "long", day: "numeric" }).format(new Date(d));
  } catch { return "—"; }
}
function faTime(d) {
  if (!d) return "—";
  try { return new Intl.DateTimeFormat("fa-IR", { hour: "2-digit", minute: "2-digit" }).format(new Date(d)); } catch { return "—"; }
}
function faWeekday(d) {
  if (!d) return "";
  try { return new Intl.DateTimeFormat("fa-IR", { weekday: "long" }).format(new Date(d)); } catch { return ""; }
}
function timeAgo(d) {
  const mins = Math.floor((Date.now() - new Date(d).getTime()) / 60000);
  if (mins < 1) return "لحظاتی پیش";
  if (mins < 60) return faNum(mins) + " دقیقه پیش";
  const h = Math.floor(mins / 60);
  if (h < 24) return faNum(h) + " ساعت پیش";
  return faNum(Math.floor(h / 24)) + " روز پیش";
}
/* جلوگیری از XSS هنگام تزریق داده به HTML */
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* ─── رنگ و لوگوی تیم ─── */
const CREST_COLORS = [
  ["#c8102e", "#8a0b20"], ["#0d47a1", "#082c66"], ["#0f9d58", "#0a6b3c"],
  ["#e0a800", "#9c7500"], ["#5e35b1", "#3b1f75"], ["#00838f", "#00525a"],
  ["#d84315", "#972c0c"], ["#37474f", "#1b262b"], ["#ad1457", "#6d0b36"], ["#2e7d32", "#164a1c"],
];
function teamColors(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return CREST_COLORS[h % CREST_COLORS.length];
}
function teamShort(name) {
  const w = name.split(/\s+/).filter(Boolean);
  if (w.length === 1) return w[0].slice(0, 2);
  return w.slice(0, 2).map((x) => x[0]).join("‌");
}
/* لوگوی تیم: اگر مسیر لوگو ثبت شده باشد عکس، در غیر این صورت نشان حروف */
function crestHtml(name, size) {
  size = size || 38;
  const logo = TEAM_LOGOS[name];
  if (!isPlaceholder(logo)) {
    return `<img class="crest" src="${esc(logo)}" alt="${esc(name)}" style="width:${size}px;height:${size}px;object-fit:contain;background:#fff;padding:2px" />`;
  }
  const [c1, c2] = teamColors(name);
  return `<span class="crest" style="width:${size}px;height:${size}px;font-size:${Math.round(size * 0.34)}px;background:linear-gradient(135deg,${c1},${c2})">${esc(teamShort(name))}</span>`;
}
function crestSvg(size) {
  size = size || 52;
  return `<svg viewBox="0 0 100 112" width="${size}" height="${(size * 112) / 100}" aria-hidden>
    <defs><linearGradient id="cg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#192f53"/><stop offset="1" stop-color="#060f1e"/></linearGradient>
    <linearGradient id="cg2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f5cf68"/><stop offset="1" stop-color="#c58518"/></linearGradient></defs>
    <path d="M50 4 L94 16 V56 C94 86 74 102 50 109 C26 102 6 86 6 56 V16 Z" fill="url(#cg1)" stroke="url(#cg2)" stroke-width="3.5"/>
    <path d="M6 40 H94 V52 H6 Z" fill="#0fba60" opacity="0.9"/>
    <circle cx="50" cy="64" r="17" fill="#f4f6f3"/>
    <path d="M50 55 l6 4.4 -2.3 7 h-7.4 l-2.3 -7 z" fill="#0a172c"/>
    ${[0, 1, 2, 3, 4].map((i) => `<path transform="translate(${18 + i * 16} 22) scale(0.9)" d="M0 -6 L1.8 -1.8 L6.3 -1.4 L2.9 1.7 L3.9 6.2 L0 3.8 L-3.9 6.2 L-2.9 1.7 L-6.3 -1.4 L-1.8 -1.8 Z" fill="url(#cg2)"/>`).join("")}
    <path d="M20 90 Q50 100 80 90" stroke="url(#cg2)" stroke-width="2.5" fill="none"/>
  </svg>`;
}

/* ─── احراز هویت (توکن در localStorage + کوکی به‌عنوان پشتیبان) ─── */
const Auth = {
  key: "bfa_token",
  get() { try { return localStorage.getItem(this.key); } catch { return null; } },
  set(t) { try { localStorage.setItem(this.key, t); } catch {} },
  clear() { try { localStorage.removeItem(this.key); } catch {} },
  /* توکن هم در هدر Authorization و هم در هدر سفارشی فرستاده می‌شود
     چون بعضی هاست‌های اشتراکی هدر Authorization را حذف می‌کنند */
  headers() {
    const t = this.get();
    return t ? { Authorization: "Bearer " + t, "X-BFA-Token": t } : {};
  },
  async session() {
    try {
      const r = await fetch(resolveApi("/api/auth"), { headers: this.headers() });
      if (!r.ok) return null;
      return await r.json();
    } catch { return null; }
  },
  async logout() {
    this.clear();
    await fetch(resolveApi("/api/auth"), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "logout" }) }).catch(() => {});
  },
};

/* ─── ارتباط با بک‌اند (با تلاش مجدد خودکار در قطعی شبکه) ─── */

/* تبدیل آدرس‌های API به فایل‌های PHP — بدون نیاز به .htaccess
   مثال: /api/auth → api/auth.php
         /api/public?section=home → api/public.php?section=home
         /api/file/abc.png → api/file.php?name=abc.png            */
function resolveApi(url) {
  var m = String(url).match(/^\/?api\/([a-z]+)(?:\/([^?\/]*))?(\?.*)?$/);
  if (!m) return url;
  var out = "api/" + m[1] + ".php";
  var q = "";
  if (m[2]) q = "?name=" + encodeURIComponent(decodeURIComponent(m[2]));
  if (m[3]) q += (q ? "&" : "?") + m[3].slice(1);
  return out + q;
}

async function fetchWithRetry(url, options, tries) {
  tries = tries || 4;
  let lastErr = null;
  for (let i = 0; i < tries; i++) {
    try {
      return await fetch(url, options);
    } catch (e) {
      lastErr = e; // خطای شبکه (مثل Failed to fetch) → تلاش مجدد
      await new Promise((r) => setTimeout(r, 600 * (i + 1)));
    }
  }
  throw new Error("اتصال به سرور برقرار نشد. اتصال اینترنت را بررسی و صفحه را دوباره باز کنید.");
}
async function api(path) {
  const r = await fetchWithRetry(resolveApi(path), { headers: Auth.headers() });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || "خطا در ارتباط با سرور");
  return data;
}
async function apiPost(path, body) {
  const r = await fetchWithRetry(resolveApi(path), {
    method: "POST",
    headers: { "Content-Type": "application/json", ...Auth.headers() },
    body: JSON.stringify(body),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || "خطا در ارتباط با سرور");
  return data;
}

/* ─── پیام خطای اتصال + دکمه تلاش مجدد ─── */
function fatalApiError(container, err) {
  if (!container) return toast(err.message, false);
  container.innerHTML = `
    <div class="empty" style="padding:60px 20px">
      <div style="font-size:40px;margin-bottom:12px">📡</div>
      <b style="color:var(--navy-800)">${esc(err.message)}</b>
      <div style="margin-top:16px"><button class="btn btn-navy btn-sm" onclick="location.reload()">🔄 تلاش مجدد</button></div>
    </div>`;
}

/* ─── خواندن فایل عکس برای آپلود ─── */
function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error("خواندن فایل ناموفق بود."));
    r.readAsDataURL(file);
  });
}

/* ─── توست (پیام کوتاه) ─── */
function toast(msg, ok = true) {
  const el = document.createElement("div");
  el.className = "toast " + (ok ? "toast-ok" : "toast-err");
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3600);
}

/* ─── ظاهرشدن با اسکرول ─── */
function initReveal() {
  const obs = new IntersectionObserver((entries) => {
    entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("is-visible"); obs.unobserve(e.target); } });
  }, { threshold: 0.12 });
  document.querySelectorAll(".reveal").forEach((el) => obs.observe(el));
}

/* ─── 📷 تصویر شاخص خبر/کارت ───
   آدرس عکس خبر از پنل مدیریت ثبت می‌شود؛ تا قبل از آن این جای خالی دیده می‌شود. */
function newsThumbHtml(n, extraCls) {
  if (!isPlaceholder(n.image)) return `<img src="${esc(n.image)}" alt="" loading="lazy" />`;
  return `<div class="thumb-empty ${extraCls || ""}"><span>تصویر خبر</span><small>آدرس عکس</small></div>`;
}

/* ─── هدر و فوتر مشترک ─── */
function renderHeader(active) {
  const today = (() => { try { return new Intl.DateTimeFormat("fa-IR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date()); } catch { return ""; } })();
  const nav = [
    { label: "خانه", href: "index.html", key: "home" },
    { label: "اخبار", key: "news", children: [
      { label: "آرشیو اخبار", href: "news.html", desc: "آرشیو کامل اخبار رسمی هیئت" },
      { label: "دوره‌های آموزشی", href: "courses.html", desc: "مربیگری، داوری و کارگاه‌ها" },
      { label: "گالری تصاویر", href: "gallery.html", desc: "تصاویر مسابقات و رویدادها" },
    ]},
    { label: "مسابقات", key: "matches", children: [
      { label: "نتایج و برنامه مسابقات", href: "matches.html", desc: "کلیه دیدارهای فوتبال و فوتسال" },
    ]},
    { label: "جداول", key: "tables", children: [
      { label: "جدول رده‌های سنی فوتبال", href: "standings.html", desc: "۸ تا ۱۲، ۱۲ تا ۱۵، ۱۵ تا ۱۸ و بزرگسالان" },
      { label: "لیگ‌های فوتسال", href: "futsal.html", desc: "کشوری، استان، شهرستان و لیگ‌های آزاد" },
    ]},
    { label: "داوران", href: "referees.html", key: "referees" },
    { label: "درباره هیئت", href: "about.html", key: "about" },
  ];
  const navHtml = nav.map((n) => {
    if (n.children) {
      return `<div class="dropdown">
        <a href="${n.children[0].href}" class="${active === n.key ? "active" : ""}">${n.label} ▾</a>
        <div class="dropdown-menu">
          <div class="dropdown-head stripe-slash">${n.label}</div>
          ${n.children.map((c) => `<a href="${c.href}">${c.label}<small>${c.desc}</small></a>`).join("")}
        </div>
      </div>`;
    }
    return `<a href="${n.href}" class="${active === n.key ? "active" : ""}">${n.label}</a>`;
  }).join("");

  const mobileHtml = nav.map((n) =>
    `<a href="${n.href || n.children[0].href}">${n.label}</a>` +
    (n.children ? n.children.map((c) => `<a href="${c.href}" style="margin-right:14px;background:#fff;border-right:2px solid var(--pitch-200)">${c.label}</a>`).join("") : "")
  ).join("");

  const el = document.getElementById("site-header");
  if (!el) return;
  el.innerHTML = `
    <div class="topbar"><div class="container">
      <span>● ${today || "سامانه رسمی هیئت فوتبال شهرستان بیرجند"}</span>
      <div>
        <a href="talent.html">طرح استعدادیابی</a>
        <a href="register-club.html">ثبت باشگاه</a>
        <a href="club-login.html">ورود باشگاه‌ها</a>
        <a href="admin-login.html" style="background:var(--navy-800);padding:3px 10px;border-radius:6px">ورود مدیریت</a>
      </div>
    </div></div>
    <div class="mainbar"><div class="container">
      <a class="brand" href="index.html">
        ${logoHtml(52)}
        <div><div class="brand-title">هیئت فوتبال شهرستان بیرجند</div><div class="brand-sub">Birjand Football Association · خراسان جنوبی</div></div>
      </a>
      <nav class="nav">${navHtml}<a href="register-club.html" class="btn btn-sm" style="margin-right:8px">ثبت‌نام باشگاه</a></nav>
      <button class="menu-btn" onclick="document.getElementById('mobile-menu').classList.toggle('open')" aria-label="منو">☰</button>
    </div></div>
    <div class="mobile-menu" id="mobile-menu">${mobileHtml}</div>
    <div class="ticker"><div class="ticker-track" id="ticker-track" dir="ltr"></div></div>`;
  loadTicker();
}

async function loadTicker() {
  try {
    const data = await api("/api/public?section=matches");
    const items = [];
    const live = data.matches.find((m) => m.status === "LIVE");
    if (live) items.push("● هم‌اکنون یک دیدار به‌صورت زنده در حال برگزاری است — گزارش لحظه‌ای در سامانه");
    data.matches.filter((m) => m.status === "FINISHED").slice(0, 8).forEach((m) => {
      items.push(`${LEAGUES[m.league]?.short || ""} · هفته ${faNum(m.week)}: ${m.homeName} ${faNum(m.homeScore)} - ${faNum(m.awayScore)} ${m.awayName}`);
    });
    const track = document.getElementById("ticker-track");
    if (!track) return;
    if (items.length) {
      track.innerHTML = items.concat(items).map((t) => `<span class="ticker-item" dir="rtl"><b>◆</b>${esc(t)}</span>`).join("");
    } else {
      track.parentElement.style.display = "none";
    }
  } catch {
    const track = document.getElementById("ticker-track");
    if (track) track.parentElement.style.display = "none";
  }
}

function renderFooter() {
  const el = document.getElementById("site-footer");
  if (!el) return;
  el.innerHTML = `
  <div class="footer"><div class="pitch-lines">
    <div class="container">
      <div class="footer-grid">
        <div>
          <div class="brand" style="color:#fff">${logoHtml(56)}<div><div class="brand-title" style="color:#fff">هیئت فوتبال شهرستان بیرجند</div><div class="brand-sub" style="color:var(--pitch-400)">زیرمجموعه هیئت فوتبال استان خراسان جنوبی</div></div></div>
          <p style="margin-top:14px;font-size:12.5px;color:var(--navy-300);line-height:2">متولی رسمی توسعه، سازمان‌دهی و نظارت بر فوتبال و فوتسال شهرستان بیرجند در کلیه رده‌های سنی؛ از مدارس فوتبال تا لیگ‌های بزرگسالان و حضور در مسابقات کشوری.</p>
        </div>
        <div><h4>دسترسی سریع</h4><ul>
          <li><a href="news.html">◆ اخبار</a></li>
          <li><a href="standings.html">◆ جدول رده‌های سنی فوتبال</a></li>
          <li><a href="futsal.html">◆ لیگ‌های فوتسال</a></li>
          <li><a href="matches.html">◆ نتایج و برنامه مسابقات</a></li>
          <li><a href="register-club.html">◆ ثبت‌نام باشگاه‌ها</a></li>
          <li><a href="talent.html">◆ طرح استعدادیابی</a></li>
        </ul></div>
        <div><h4>کمیته‌ها و بخش‌ها</h4><ul>
          <li><a href="matches.html">◆ کمیته مسابقات</a></li>
          <li><a href="referees.html">◆ کمیته داوران</a></li>
          <li><a href="courses.html">◆ کمیته آموزش</a></li>

          <li><a href="about.html">◆ پیشکسوتان و تاریخچه</a></li>
          <li><a href="about.html#rules">◆ قوانین و آیین‌نامه‌ها</a></li>
        </ul></div>
        <div><h4>تماس با هیئت</h4><ul>
          <!-- 📮 آدرس و راه‌های تماس را در صورت نیاز از اینجا ویرایش کنید -->
          <li>بیرجند، معلم، مجتمع ورزشی سرحدی، دفتر هیئت فوتبال شهرستان بیرجند</li>
          <li style="font-weight:800;color:#fff" dir="ltr">0000000000</li>
          <li style="color:var(--navy-400)">ساعات پاسخ‌گویی: شنبه تا پنج‌شنبه ۱۶ تا ۲۰</li>
        </ul>
        <div style="display:flex;gap:8px;margin-top:12px">${["اینستاگرام", "آپارات", "سروش"].map((s) => `<span style="border:1px solid var(--navy-700);border-radius:8px;padding:6px 12px;font-size:11px;cursor:pointer">${s}</span>`).join("")}</div>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© ۱۴۰۵ هیئت فوتبال شهرستان بیرجند — کلیه حقوق محفوظ است.</span>
        <span><a href="about.html#rules">قوانین</a> · <a href="admin-login.html">سامانه مدیریت</a></span>
      </div>
      <div class="footer-bottom" style="border-top:none;padding-top:0">
        <span style="color:var(--navy-300)">ساخته شده و طراحی شده توسط <b style="color:var(--gold-400)">داریوش شیبانی</b></span>
      </div>
    </div>
  </div></div>`;
}

/* ─── کارت مسابقه ─── */
function matchCardHtml(m, compact) {
  const live = m.status === "LIVE";
  const finished = m.status === "FINISHED";
  const scoreHtml = finished || live
    ? `<div class="score">${faNum(m.homeScore ?? 0)} - ${faNum(m.awayScore ?? 0)}</div>`
    : `<div class="time">${faTime(m.dateTime)}</div>`;
  return `<a href="matches.html?id=${m.id}" class="match-card ${live ? "live" : ""}" style="margin-bottom:${compact ? "10px" : "0"}">
    ${live ? `<span class="live-badge"><span class="live-dot"></span>زنده</span>` : ""}
    <div class="mc-main">
      <div class="mc-team">${crestHtml(m.homeName, compact ? 30 : 38)}<span>${esc(m.homeName)}</span></div>
      <div class="mc-score">${scoreHtml}<small>${live ? "در حال برگزاری" : finished ? "پایان یافته" : faDate(m.dateTime, { month: "long", day: "numeric" })}</small></div>
      <div class="mc-team away"><span>${esc(m.awayName)}</span>${crestHtml(m.awayName, compact ? 30 : 38)}</div>
    </div>
    <div class="mc-foot"><span>${esc(m.venue || "—")}</span><span>${faWeekday(m.dateTime)} ${faDate(m.dateTime, { month: "long", day: "numeric" })}</span></div>
  </a>`;
}

/* ─── فرم ۵ بازی اخیر ─── */
function formDotsHtml(form) {
  if (!form || !form.length) return '<span style="color:var(--navy-300);font-size:11px">—</span>';
  const label = { W: "ب", D: "م", L: "خ" };
  return `<span class="form-dots">${form.map((f) => `<span class="form-dot form-${f}">${label[f]}</span>`).join("")}</span>`;
}

/* ─── ردیف جدول رده‌بندی ─── */
function standingRowHtml(r, idx, highlightTeam) {
  const rankCls = idx === 0 ? "rank-1" : idx < 3 ? "rank-" + (idx + 1) : "rank-n";
  const rowCls = (idx === 0 ? " first" : "") + (highlightTeam && r.team.includes(highlightTeam) ? " birjand" : "");
  return `<tr class="${rowCls}">
    <td style="text-align:right;padding-right:18px"><span class="rank-badge ${rankCls}">${faNum(idx + 1)}</span></td>
    <td style="text-align:right"><div class="team-cell">${crestHtml(r.team, 26)}<span>${esc(r.team)}</span>${idx === 0 ? '<span class="badge badge-gold" style="margin-right:6px">صدرنشین</span>' : ""}${highlightTeam && r.team.includes(highlightTeam) ? '<span class="badge badge-pitch" style="margin-right:6px">نماینده بیرجند</span>' : ""}</div></td>
    <td>${faNum(r.played)}</td>
    <td style="color:var(--pitch-700)">${faNum(r.wins)}</td>
    <td style="color:var(--gold-600)">${faNum(r.draws)}</td>
    <td style="color:var(--red)">${faNum(r.losses)}</td>
    <td>${faNum(r.gf)}</td>
    <td>${faNum(r.ga)}</td>
    <td style="font-weight:800;color:${r.gd > 0 ? "var(--pitch-600)" : r.gd < 0 ? "var(--red)" : "var(--navy-400)"}">${r.gd > 0 ? "+" : ""}${faNum(r.gd)}</td>
    <td><span class="pts-badge">${faNum(r.points)}</span></td>
    <td>${formDotsHtml(r.form)}</td>
  </tr>`;
}

const STANDINGS_HEAD = `<tr>
  <th style="text-align:right;padding-right:18px">رتبه</th><th class="team-col">نام تیم</th>
  <th>بازی</th><th>برد</th><th>مساوی</th><th>باخت</th><th>گل زده</th><th>گل خورده</th><th>تفاضل</th><th>امتیاز</th><th>فرم اخیر</th>
</tr>`;
