<?php
/* ═══════════════════════════════════════════════════════════
   احراز هویت: توکن امضاشده با HMAC
   سازگار با PHP 7.0 به بالا
   ═══════════════════════════════════════════════════════════ */
require_once dirname(__FILE__) . '/config.php';

function b64url_encode($s) {
    return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
}

function b64url_decode($s) {
    $pad = strlen($s) % 4;
    if ($pad) $s .= str_repeat('=', 4 - $pad);
    return base64_decode(strtr($s, '-_', '+/'));
}

function sign_payload($payload) {
    return b64url_encode(hash_hmac('sha256', $payload, TOKEN_SECRET, true));
}

/* ساخت توکن نشست */
function make_token($session) {
    $payload = b64url_encode(json_encode($session, JSON_UNESCAPED_UNICODE));
    return $payload . '.' . sign_payload($payload);
}

/* اعتبارسنجی و خواندن توکن */
function decode_token($token) {
    if (!$token || substr_count($token, '.') !== 1) return null;
    $parts = explode('.', $token);
    $payload = $parts[0];
    $sig = $parts[1];
    $expected = sign_payload($payload);
    if (!hash_equals($expected, $sig)) return null;
    $data = json_decode(b64url_decode($payload), true);
    if (!is_array($data)) return null;
    $role = isset($data['role']) ? $data['role'] : '';
    if ($role === 'admin') return array('role' => 'admin');
    if ($role === 'club' && isset($data['clubId'])) {
        return array(
            'role' => 'club',
            'clubId' => (int)$data['clubId'],
            'name' => isset($data['name']) ? $data['name'] : '',
        );
    }
    return null;
}

/* خواندن یک هدر از درخواست (سازگار با همه هاست‌ها) */
function get_header($name) {
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        if (is_array($headers)) {
            foreach ($headers as $k => $v) {
                if (strtolower($k) === strtolower($name)) return $v;
            }
        }
    }
    $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    return isset($_SERVER[$key]) ? $_SERVER[$key] : '';
}

/* خواندن نشست از هدر Authorization یا هدر سفارشی یا کوکی */
function get_session() {
    $auth = get_header('Authorization');
    if (strpos($auth, 'Bearer ') === 0) {
        $s = decode_token(substr($auth, 7));
        if ($s) return $s;
    }
    /* بعضی هاست‌های اشتراکی هدر Authorization را حذف می‌کنند */
    $custom = get_header('X-BFA-Token');
    if ($custom !== '') {
        $s = decode_token($custom);
        if ($s) return $s;
    }
    if (isset($_COOKIE['bfa_token'])) {
        $s = decode_token($_COOKIE['bfa_token']);
        if ($s) return $s;
    }
    return null;
}

function require_admin() {
    $s = get_session();
    if (!$s || $s['role'] !== 'admin') json_out(array('error' => 'دسترسی غیرمجاز'), 401);
    return $s;
}

function require_club() {
    $s = get_session();
    if (!$s || $s['role'] !== 'club') json_out(array('error' => 'دسترسی غیرمجاز'), 401);
    return $s;
}

function set_session_cookie($token) {
    setcookie('bfa_token', $token, time() + 7 * 24 * 3600, '/');
}

function clear_session_cookie() {
    setcookie('bfa_token', '', time() - 3600, '/');
}

function verify_admin_key($key) {
    /* رمز مدیر همان رمز یکپارچه پنل‌ها (PANEL_PASSWORD) است */
    return hash_equals(PANEL_PASSWORD, (string)$key);
}
